# Calor Conversion Scorecard

**Commit:** `5e52d8ab`
**Date:** 2026-10-08 19:06:54 UTC

## Summary

| Metric | Count | Rate |
|--------|-------|------|
| Fully converted | 93/100 | 93% |
| Partially converted | 7/100 | 7% |
| Blocked | 0/100 | 0% |
| Crashed | 0/100 | 0% |
| **Round-trip verified** | **97/100** | **97%** |

## By Level

| Level | Passing | Total | Rate |
|-------|---------|-------|------|
| Level 1 | 20 | 20 | 100% |
| Level 2 | 20 | 20 | 100% |
| Level 3 | 20 | 20 | 100% |
| Level 4 | 19 | 20 | 95% |
| Level 5 | 18 | 20 | 90% |

## By C# Feature (lowest conversion rates)

| Feature | Passing | Total | Rate |
|---------|---------|-------|------|
| record | 0 | 2 | 0% |
| unary_minus | 0 | 1 | 0% |
| unary_plus | 0 | 1 | 0% |
| positional_record | 0 | 1 | 0% |
| local_function | 0 | 1 | 0% |
| generic_method | 0 | 1 | 0% |
| type_constraint | 0 | 1 | 0% |
| generic_constraint | 0 | 1 | 0% |
| where_clause | 0 | 1 | 0% |
| new_constraint | 0 | 1 | 0% |
| with_expression | 0 | 1 | 0% |
| computed_property | 0 | 1 | 0% |
| indexer | 1 | 2 | 50% |
| binary_expression | 6 | 6 | 100% |
| for_loop | 6 | 6 | 100% |
| linq | 5 | 5 | 100% |
| parameters | 4 | 4 | 100% |
| static_class | 3 | 3 | 100% |
| recursion | 3 | 3 | 100% |
| namespace | 2 | 2 | 100% |

## Failed Snippets

| ID | File | Status | Top Issue |
|----|------|--------|-----------|
| 078 | Level4_Methods/078_IndexerProperty.cs | PartiallyConverted | Warning [nullable-oblivious-nested-shape] (line 5, col 17): Nested oblivious ... |
| 086 | Level5_Advanced/086_GenericMethod.cs | PartiallyConverted | Warning [nullable-oblivious-nested-shape] (line 17, col 23): Nested oblivious... |
| 098 | Level5_Advanced/098_GenericConstraints.cs | PartiallyConverted | Warning [interface]: Feature 'interface' is partially supported. Keep default... |
