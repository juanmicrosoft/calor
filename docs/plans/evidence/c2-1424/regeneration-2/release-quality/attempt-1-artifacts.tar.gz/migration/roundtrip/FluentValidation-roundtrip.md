# FluentValidation — Round-Trip Verification Report

**Calor Version:** 0.24.0
**Date:** 2026-10-08
**Duration:** 33.3s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `cda8afbf258647cdbc6eb0c26f51ff1a`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 1
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 865 passed, 0 failed, 1 skipped |
| Files converted | 97/139 (69.8%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 15 |
| Build after replacement | Success |
| Round-trip tests | 865 passed, 0 failed, 1 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **69.8%** (97/139) |
| Converted natively (zero losses) | 93 (66.9%) |
| Converted with losses | 4 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 42 |
| Excluded by pattern (coverage failures in denominator) | 0 |
| Minimum total coverage | 50.0% |
| Minimum native coverage | 48.0% |
| Interop blocks (raw C# preserved) | 30 |
| Distinct semantic gaps | 1 |
| Loss ledger by kind | InteropPreserved: 30, PreprocessorStripped: 18 |

Gap features: `preprocessor-directive`

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 865/866 passed (1 TRX file(s))
- Round-trip: 865/866 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/FluentValidation/AbstractValidator.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'Validate' matches (OBJECT). Candidates: FluentVali... |
| src/FluentValidation/AssemblyInfo.FluentValidation.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/FluentValidation/AssemblyScanner.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'AssemblyScanner..ctor' matches (OBJECT). Candidate... |
| src/FluentValidation/AsyncValidatorInvokedSynchronouslyException.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | Compile Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | Lambda parameter '_' is already defined |
| src/FluentValidation/DefaultValidatorOptions.cs | Compile Error | single-context-selected | 1 | 100% | 3 | 3 | - | Lambda parameter '_' is already defined |
| src/FluentValidation/Enums.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/ICollectionRule.cs | Emit Error | single-context-selected | 1 | 100% | 0 | 0 | - | CS1003: Syntax error, ',' expected (line 15) |
| src/FluentValidation/InlineValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/AccessorCache.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 1 | 1 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/ChildRulesContainer.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | Emit Error | single-context-selected | 1 | 100% | 6 | 0 | preprocessor-directive | CS1525: Invalid expression term '}' (line 308) |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 2 | 2 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/Extensions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Binding 'tmp' has no type annotation and no initializer. Add either ':type' (e.g... |
| src/FluentValidation/Internal/IncludeRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/IRuleComponent.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/MessageBuilderContext.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'Component' is already defined in 'FluentValidation.Internal.MessageBui... |
| src/FluentValidation/Internal/MessageFormatter.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'AppendArgument' matches (STRING?, STRING?). Candid... |
| src/FluentValidation/Internal/PropertyChain.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/PropertyRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/RuleBase.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Binding 'index' has no type annotation and no initializer. Add either ':type' (e... |
| src/FluentValidation/Internal/RuleBuilder.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'Rule' is already defined in 'FluentValidation.Internal.RuleBuilder`2' |
| src/FluentValidation/Internal/RuleComponent.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/TrackingCollection.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Internal/ValidationStrategy.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/IValidationContext.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | Property 'Failures' is already defined in 'FluentValidation.ValidationContext`1' |
| src/FluentValidation/IValidationRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/IValidationRuleInternal.cs | Replaced | single-context-selected | 1 | 0% | 2 | 2 | - | - |
| src/FluentValidation/IValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/IValidatorDescriptor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/IValidatorFactory.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/ILanguageManager.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/LanguageManager.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ThaiLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Results/ValidationFailure.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Results/ValidationResult.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Syntax.cs | Emit Error | single-context-selected | 1 | 100% | 2 | 2 | - | CS1003: Syntax error, ',' expected (line 18) |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | '§YIELD' is illegal inside a property/indexer accessor. |
| src/FluentValidation/TestHelper/TestValidationResult.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/TestHelper/ValidationTestException.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'GetModelLevelValidators' matches <T>(OBJECT). Cand... |
| src/FluentValidation/ValidationException.cs | Compile Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | No overload of internal call 'FluentValidation.ValidationException..ctor' matche... |
| src/FluentValidation/ValidatorDescriptor.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 4 | 4 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/ValidatorFactoryBase.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/ValidatorOptions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Abs... |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/AsyncPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Validators/ComparableComparer.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Validators/EmailValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Validators/EmptyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/EnumValidator.cs | Compile Error | single-context-selected | 1 | 100% | 8 | 8 | - | No overload of internal call 'IsFlagsEnumDefined' matches (OBJECT, TProperty). C... |
| src/FluentValidation/Validators/EqualValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Equ... |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/GreaterThanValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/LengthValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/tmp/claude-501/-Users-juanrivera-repos-juanmicrosoft-calor/98372634-e96... |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/LessThanValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NoopPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NotEmptyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Not... |
| src/FluentValidation/Validators/NotNullValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NullValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | Binding 'derivedValidatorFactory' has no type annotation and no initializer. Add... |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/FluentValidation/Validators/PredicateValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/PropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/RangeValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'From' is already defined in 'FluentValidation.Validators.RangeValidato... |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/StringEnumValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:11 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:10 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:10 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:39 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:2 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:50 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:2 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 107:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115:43 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115:17 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 134:60 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:66 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 182:35 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 182:60 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183: | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 194:17 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 210:62 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 210:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 212:3 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 224:74 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 224:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 226:3 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 256:32 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 256:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:32 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:34 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 290:34 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 290:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 302:37 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 302:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 314:37 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 314:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 325:39 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 325:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 336:39 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 336:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 345:22 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 347:3 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 355:34 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 357:3 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 369:9 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 380:37 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 380:67 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 389:50 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 389:80 | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 397:37 | - |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 38:12 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 154:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 168:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 267:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 276:9 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:11 | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:25 | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:59 | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:10 | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:22 | - |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 105:9 | - |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 27:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 40:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 44:12 | CompilationError |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:83 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:124 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:88 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:129 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:68 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:105 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 90:77 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 90:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 102:74 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 102:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 113:78 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 113:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:75 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 136:62 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 136:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:62 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:99 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:117 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 159:62 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 159:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:62 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:99 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 181:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 181:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 194:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 194:100 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 194:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 206:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 206:100 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 206:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:100 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 231:25 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:63 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:100 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:128 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 254:69 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 254:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:69 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:78 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 280:24 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 293:64 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 294:21 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 293:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 310:78 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 311:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 311:46 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 310:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 312:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 313:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 328:64 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 329:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 329:43 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 328:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 332:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 333:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 349:75 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 349:136 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 349:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 362:61 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 362:116 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 362:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 379:75 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 379:115 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 379:158 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 379:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 380:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 381:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 396:61 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 396:98 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 396:138 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 396:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 398:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 399:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 414:74 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 414:114 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 414:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 430:74 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 430:114 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 430:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 446:74 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 446:114 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 446:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 461:79 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 461:119 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 461:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 478:79 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 478:119 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 478:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 494:79 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 494:119 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 494:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 510:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 509:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 526:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 525:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 542:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 541:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 557:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 556:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 572:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 571:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 588:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 587:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 604:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 603:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 619:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 618:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 633:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 633:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 632:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 637:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 638:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 654:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 654:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 653:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 658:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 659:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 663:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 679:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 679:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 678:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 683:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 684:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 701:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 701:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 700:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 705:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 706:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 710:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 726:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 726:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 725:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 729:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 730:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 747:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 747:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 746:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 751:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 752:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 756:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 772:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 772:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 771:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 776:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 777:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 794:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 794:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 793:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 798:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 799:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 803:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 819:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 819:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 818:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 823:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 824:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 841:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 841:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 840:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 845:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 846:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 850:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 866:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 866:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 865:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 870:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 871:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 888:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 888:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 887:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 892:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 893:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 897:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 913:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 913:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 912:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 917:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 918:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 935:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 935:48 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 934:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 939:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 940:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 944:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 960:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 960:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 959:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 964:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 965:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 969:4 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 985:8 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 985:49 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 984:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 989:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 990:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1006:86 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1006:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1020:86 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1020:156 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1020:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1033:87 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1033:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1047:86 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1047:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1062:86 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1062:156 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1062:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1075:87 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1075:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1081:66 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1081:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1091:78 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1091:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1103:71 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1103:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1115:72 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1115:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1126:86 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1126:126 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1126:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1142:91 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1142:131 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1142:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1158:88 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1159:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1158:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1165:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1166:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1167:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1187:66 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1187:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1199:80 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1199:120 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1199:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1204:3 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1236:92 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1236:132 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1236:16 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 1243:72 | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 367:21 | CompilationError |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:50 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:87 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:16 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:61 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:98 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:16 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:46 | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:57 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:126 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:126 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:87 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:143 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:73 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:91 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:77 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:124 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 108:87 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 108:144 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 108:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:81 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 131:81 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 131:121 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 131:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:81 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:121 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 159:83 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 159:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 173:73 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 173:113 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 173:138 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 173:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 186:83 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 186:133 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 186:158 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 186:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:74 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:114 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:161 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 214:84 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 214:134 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 214:181 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 214:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:76 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:116 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:141 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 229:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:86 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:136 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:161 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:76 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:116 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:163 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:86 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:136 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:183 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 281:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 281:119 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 281:169 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 281:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 294:89 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 294:139 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 294:189 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 294:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 307:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 307:119 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 307:191 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 307:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 322:89 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 322:139 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 322:211 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 322:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 337:81 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 337:121 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 337:171 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 337:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 350:91 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 350:141 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 350:191 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 350:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363:81 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363:121 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363:193 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 376:91 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 376:141 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 376:213 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 376:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 387:103 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 387:162 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 387:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 400:108 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 400:167 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 400:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 412:78 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 412:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 424:78 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 424:118 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 424:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 443:90 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 443:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 457:90 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 457:130 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 457:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 459:3 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 472:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 472:119 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 472:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 487:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 487:119 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 487:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 506:79 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 506:119 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 506:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 525:82 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 525:122 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 525:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 538:82 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 538:122 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 538:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 541: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 538: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 557:82 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 557:122 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 557:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 560: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 557: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 576:82 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 576:122 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 576:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 579: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 576: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 593:113 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 593:172 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 593:16 | - |
| src/FluentValidation/DefaultValidatorOptions.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 416:52 | CompilationError |
| src/FluentValidation/ICollectionRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ICollectionRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:9 | - |
| src/FluentValidation/ICollectionRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:9 | - |
| src/FluentValidation/ICollectionRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:9 | - |
| src/FluentValidation/ICollectionRule.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 15:76 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:2 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:2 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:2 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 74: | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:2 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:11 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:9 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 107:49 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 107:78 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:51 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:80 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:118 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:152 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:77 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:16 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 139:9 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 144:9 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 154:9 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183:10 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 190:11 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 204:16 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 247:129 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 247:9 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:3 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 274:10 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 281:25 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 308:10 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 326:68 | - |
| src/FluentValidation/IValidationContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 41:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 51:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 83:9 | CompilationError |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:9 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:22 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:20 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:25 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:79 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:2 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:9 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:22 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:66 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:27 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:96 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 89:28 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:33 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 123:2 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:2 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 134:24 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 171:2 | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 176:2 | - |
| src/FluentValidation/IValidationRule.cs | project-candidate-validation | MSBuildReportedLocation | CS1961 | Error | 27:12 | - |
| src/FluentValidation/IValidationRule.cs | project-candidate-validation | MSBuildReportedLocation | CS1961 | Error | 27:12 | - |
| src/FluentValidation/IValidationRuleInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 26: | - |
| src/FluentValidation/IValidationRuleInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 33: | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:2 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:2 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:28 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:2 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64:39 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64:2 | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:2 | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:2 | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:2 | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:2 | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:2 | - |
| src/FluentValidation/IValidatorFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidatorFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:2 | - |
| src/FluentValidation/IValidatorFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:2 | - |
| src/FluentValidation/InlineValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:29 | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 13:26 | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:83 | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:16 | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:33 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 38:41 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 38:23 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 38:41 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 38:23 | - |
| src/FluentValidation/Internal/ChildRulesContainer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:11 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:51 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:96 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:125 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:9 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:9 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:9 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:59 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:114 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:16 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64:3 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:3 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:59 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 112:3 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:5 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 167:7 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 193:52 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:88 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:16 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 206:3 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 225:42 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | emitted-syntax | EmittedCSharp | CS1525 | Error | 308:23 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | emitted-syntax | EmittedCSharp | CS1002 | Error | 308:23 | - |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:10 | - |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:36 | - |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:25 | - |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:68 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:10 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:26 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:32 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:9 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 39: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 87:34 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 87:9 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:10 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:31 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 105:37 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 105:9 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 105: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 152:39 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 152:9 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 158:10 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 159:19 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 161:35 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 161:89 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:3 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 182:10 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183:19 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 185:40 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 185:94 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 193:3 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:35 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:38 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:41 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:44 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:53 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4032 | Error | 84:25 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 86:26 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 156:40 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:51 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4033 | Error | 178:29 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 179:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 179:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:35 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:38 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:41 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:44 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:53 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4032 | Error | 84:25 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 86:26 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 156:40 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:51 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4033 | Error | 178:29 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 179:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 179:27 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:25 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:68 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 16:67 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 16:67 | - |
| src/FluentValidation/Internal/Extensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:56 | - |
| src/FluentValidation/Internal/Extensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:3 | - |
| src/FluentValidation/Internal/Extensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:40 | - |
| src/FluentValidation/Internal/Extensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:17 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:50 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:37 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:83 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:64 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 55:11 | - |
| src/FluentValidation/Internal/IRuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 31: | - |
| src/FluentValidation/Internal/IRuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IRuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 89:2 | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:18 | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:61 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:21 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:46 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:21 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:73 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:38 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:63 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:16 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:50 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:76 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:16 | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:48 | - |
| src/FluentValidation/Internal/IncludeRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0508 | Error | 63:32 | - |
| src/FluentValidation/Internal/IncludeRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0508 | Error | 63:32 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:11 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:25 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:37 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:9 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:26 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:69 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:62 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:16 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 150:48 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 151:3 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 38:5 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 39:34 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 173:58 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 38:5 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 39:34 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 173:58 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 6:2 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 7:2 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 8:2 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 11:2 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 18:10 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:31 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:83 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:9 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:2 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:9 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:9 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:9 | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Internal/MessageFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:11 | - |
| src/FluentValidation/Internal/MessageFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/MessageFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:25 | - |
| src/FluentValidation/Internal/MessageFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 96:9 | - |
| src/FluentValidation/Internal/MessageFormatter.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 29:12 | CompilationError |
| src/FluentValidation/Internal/MessageFormatter.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 34:12 | CompilationError |
| src/FluentValidation/Internal/MessageFormatter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 45:13 | CompilationError |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:11 | - |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:23 | - |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:45 | - |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:3 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:41 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:74 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:103 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:50 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:93 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:16 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:3 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:3 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:47 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 118:5 | - |
| src/FluentValidation/Internal/PropertyRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 137:52 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0738 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0738 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 20:88 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:19 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:10 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:10 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:10 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:10 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:21 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:2 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:11 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:11 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 66:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:29 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 100:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 116:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 129:37 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 129:70 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 129:99 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 144:27 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 149:32 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 149:83 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 194:9 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:11 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 201:2 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 203:40 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 209:31 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:29 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:73 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 240:34 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 240:103 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 258:35 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:40 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 295:59 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 320:52 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 320:96 | - |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 320:12 | - |
| src/FluentValidation/Internal/RuleBase.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 191:11 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:2 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:21 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:65 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:56 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:61 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:3 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 66:56 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 66:96 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 66:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:68 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:114 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:68 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:125 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:9 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 96:2 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 101:2 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:27 | - |
| src/FluentValidation/Internal/RuleBuilder.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 19:7 | CompilationError |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:10 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:10 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:10 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:19 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:19 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:25 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:25 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:87 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:17 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 66:47 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:25 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:57 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:68 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:28 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 101:29 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115:34 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 125:32 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 133:49 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 144:9 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 149:9 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 163:32 | - |
| src/FluentValidation/Internal/RuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:30 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 54:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 56:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 64:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 66:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 54:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 56:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 64:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 66:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:10 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:10 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:42 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:42 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:104 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:18 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:58 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:75 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 31:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 41:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 31:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 41:27 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 11:11 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 14:27 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:9 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:34 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:33 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:76 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:3 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:31 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 42:13 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 43:71 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 52:32 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 53:38 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 42:13 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 43:71 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 52:32 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 53:38 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:11 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:15 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:10 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:33 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:31 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:23 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:9 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:12 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:12 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:26 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:56 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:12 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:12 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:28 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:58 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | project-candidate-validation | MSBuildReportedLocation | CS1551 | Error | 30:19 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | project-candidate-validation | MSBuildReportedLocation | CS1551 | Error | 30:19 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:10 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:10 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:10 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:56 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:56 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 82:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:54 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:49 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 121:9 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 126:10 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:3 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 153:11 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 47:52 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 47:52 | - |
| src/FluentValidation/Resources/ILanguageManager.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/LanguageManager.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:19 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 102:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 108:31 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 112:35 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 115:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 102:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 108:31 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 112:35 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 115:27 | - |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Results/ValidationFailure.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:9 | - |
| src/FluentValidation/Results/ValidationFailure.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:9 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:10 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:9 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:9 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:26 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:26 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:28 | - |
| src/FluentValidation/Results/ValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 113:9 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 81:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 82:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 81:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 82:35 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:49 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:54 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:49 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:89 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:61 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:107 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:61 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:118 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:2 | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 121: | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 125: | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 18:83 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 31:83 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 36:93 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 41:87 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 13:2 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 14:2 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 18:19 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:19 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:36 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:29 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:9 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:9 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:9 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | Program.Compile | ConvertedCalor | Calor0209 | Error | 35:17 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:30 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:69 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:9 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:57 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:9 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:9 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:10 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:23 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 80:28 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:23 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 80:28 | - |
| src/FluentValidation/TestHelper/ValidationTestException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:9 | - |
| src/FluentValidation/TestHelper/ValidationTestException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:49 | - |
| src/FluentValidation/TestHelper/ValidationTestException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:65 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:90 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:3 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48: | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:110 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:153 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:17 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:65 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:17 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:61 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:102 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:61 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:86 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:3 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 109:72 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 109:113 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 109:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:78 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:103 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:22 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 122:42 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 129:4 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:46 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:84 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 147:4 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:57 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:95 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 162:4 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:54 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:92 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 170:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 174:57 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 174:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 178:64 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 178:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183:58 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 187:55 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 187:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 191:65 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 191:103 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 191:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 195:68 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 195:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:69 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 203:66 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 203:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 207:46 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 207:16 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 219:3 | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 25:89 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 142:28 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 158:28 | CompilationError |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:9 | - |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:45 | - |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:45 | - |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:29 | - |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:42 | - |
| src/FluentValidation/ValidationException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:3 | - |
| src/FluentValidation/ValidationException.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 17:9 | CompilationError |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:9 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:29 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:17 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:9 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:9 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:32 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:3 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 112:9 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 132:39 | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:10 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:23 | - |
| src/FluentValidation/ValidatorFactoryBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:9 | - |
| src/FluentValidation/ValidatorFactoryBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:9 | - |
| src/FluentValidation/ValidatorFactoryBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:18 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 82:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 90:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 121:78 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 123:4 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 130:77 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 132:41 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 151:26 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 153:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 154:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 156:10 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 161:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 177:9 | - |
| src/FluentValidation/ValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 185:9 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:11 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:19 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:40 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:40 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:38 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:3 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 87:61 | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 26:7 | CompilationError |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:19 | - |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:33 | - |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:42 | - |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:18 | - |
| src/FluentValidation/Validators/AsyncPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:42 | - |
| src/FluentValidation/Validators/AsyncPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:18 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:19 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:19 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:9 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:47 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 68:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:41 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:17 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:83 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:20 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:3 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 103:59 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 103:28 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 107:37 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115:36 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 44:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 59:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 44:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 59:31 | - |
| src/FluentValidation/Validators/ComparableComparer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:18 | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:31 | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 25:32 | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 25:32 | - |
| src/FluentValidation/Validators/EmailValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:25 | - |
| src/FluentValidation/Validators/EmailValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:31 | - |
| src/FluentValidation/Validators/EmailValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:31 | - |
| src/FluentValidation/Validators/EmailValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 47:5 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 48:34 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 47:5 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 48:34 | - |
| src/FluentValidation/Validators/EmptyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:31 | - |
| src/FluentValidation/Validators/EnumValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:31 | - |
| src/FluentValidation/Validators/EnumValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EnumValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 31:14 | CompilationError |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:11 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:11 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:50 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:24 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:108 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:31 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:39 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:9 | - |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EqualValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 25:7 | CompilationError |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:65 | - |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:37 | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:37 | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:18 | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/GreaterThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:30 | - |
| src/FluentValidation/Validators/GreaterThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:30 | - |
| src/FluentValidation/Validators/GreaterThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:18 | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:26 | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:2 | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:15 | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:65 | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:9 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:9 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:25 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:43 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:31 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:30 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 101:32 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:32 | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 218:65 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 218:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 189:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 189:69 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 218:65 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 218:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 189:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 189:69 | - |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:34 | - |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:34 | - |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:18 | - |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LessThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:27 | - |
| src/FluentValidation/Validators/LessThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:27 | - |
| src/FluentValidation/Validators/LessThanValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:18 | - |
| src/FluentValidation/Validators/NoopPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:31 | - |
| src/FluentValidation/Validators/NotEmptyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:31 | - |
| src/FluentValidation/Validators/NotEmptyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:19 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:19 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:27 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:106 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:54 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:31 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:39 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:9 | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Validators/NotNullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:31 | - |
| src/FluentValidation/Validators/NotNullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/NullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:31 | - |
| src/FluentValidation/Validators/NullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:11 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:58 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:104 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:9 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:58 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:113 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:9 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:58 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:123 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:9 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:70 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:99 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 88:12 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:42 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:18 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 110:60 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 110:29 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111: | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 118:11 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:20 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 120:10 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 122:34 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 122:61 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:34 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:93 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 132:34 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 132:10 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 74:11 | - |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 67:31 | - |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 95: | - |
| src/FluentValidation/Validators/PredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:19 | - |
| src/FluentValidation/Validators/PredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:28 | - |
| src/FluentValidation/Validators/PredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:31 | - |
| src/FluentValidation/Validators/PredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/PropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:31 | - |
| src/FluentValidation/Validators/RangeValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:11 | - |
| src/FluentValidation/Validators/RangeValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:54 | - |
| src/FluentValidation/Validators/RangeValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:31 | - |
| src/FluentValidation/Validators/RangeValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:16 | - |
| src/FluentValidation/Validators/RangeValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 80:16 | - |
| src/FluentValidation/Validators/RangeValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 15:7 | CompilationError |
| src/FluentValidation/Validators/RangeValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 18:7 | CompilationError |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:11 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:3 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:36 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:55 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:3 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:36 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:36 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:36 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:64 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:31 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64:3 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:54 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:17 | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/StringEnumValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:19 | - |
| src/FluentValidation/Validators/StringEnumValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:31 | - |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

