# MediatR — Round-Trip Verification Report

**Calor Version:** 0.24.0
**Date:** 2026-10-07
**Duration:** 41.6s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `f217063d4f07413896be1394282c42ec`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 1
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 155 passed, 0 failed, 2 skipped |
| Files converted | 23/32 (71.9%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 7 |
| Build after replacement | Success |
| Round-trip tests | 155 passed, 0 failed, 2 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **71.9%** (23/32) |
| Converted natively (zero losses) | 17 (53.1%) |
| Converted with losses | 6 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 9 |
| Excluded by pattern (coverage failures in denominator) | 0 |
| Minimum total coverage | 55.0% |
| Minimum native coverage | 40.0% |
| Interop blocks (raw C# preserved) | 15 |
| Distinct semantic gaps | 0 |
| Loss ledger by kind | InteropPreserved: 15 |

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 155/157 passed (1 TRX file(s))
- Round-trip: 155/157 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/MediatR/IMediator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/INotificationHandler.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/MediatR/INotificationPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Internal/HandlersOrderer.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/MediatR/5e67734... |
| src/MediatR/Internal/ObjectDetails.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Argument to parameter 'x' declares non-nullable 'ObjectDetails' but the value ma... |
| src/MediatR/IPipelineBehavior.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/MediatR/IPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/IRequestHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/ISender.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/IStreamPipelineBehavior.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/MediatR/IStreamRequestHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Mediator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/MediatR/5e67734... |
| src/MediatR/MicrosoftExtensionsDI/RequestExceptionActionProcessorStrategy.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/NotificationHandlerExecutor.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/MediatR/NotificationPublishers/ForeachAwaitPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/NotificationPublishers/TaskWhenAllPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestExceptionAction.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestExceptionHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestPostProcessor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestPreProcessor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'GetExceptionTypes' matches (OBJECT). Candidates: M... |
| src/MediatR/Pipeline/RequestExceptionHandlerState.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'GetExceptionTypes' matches (OBJECT). Candidates: M... |
| src/MediatR/Pipeline/RequestPostProcessorBehavior.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestPreProcessorBehavior.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Registration/ServiceRegistrar.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 6 | 6 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/MediatR/5e67734... |
| src/MediatR/TypeForwardings.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/MediatR/5e67734... |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | Replaced | single-context-selected | 1 | 100% | 2 | 2 | - | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | Replaced | single-context-selected | 1 | 100% | 3 | 3 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| src/MediatR/IMediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/INotificationHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/INotificationHandler.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 16:60 | - |
| src/MediatR/INotificationHandler.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 16:60 | - |
| src/MediatR/INotificationPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/INotificationPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 9:77 | - |
| src/MediatR/IPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 12: | - |
| src/MediatR/IPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/ISender.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/ISender.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:37 | - |
| src/MediatR/ISender.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:57 | - |
| src/MediatR/IStreamPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 12: | - |
| src/MediatR/IStreamPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IStreamRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0026 | Error | 17:30 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:52 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:84 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 60:41 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0026 | Error | 17:30 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:52 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:84 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 60:41 | - |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:41 | CompilationError |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:46 | CompilationError |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:82 | CompilationError |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:87 | CompilationError |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:118 | CompilationError |
| src/MediatR/Internal/ObjectDetails.cs | Program.Compile | ConvertedCalor | Calor0274 | Error | 30:123 | CompilationError |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 18:22 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:22 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:29 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:29 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:29 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:21 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:21 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:55 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:44 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:9 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 139:99 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 142:38 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 144:9 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 155:64 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:9 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 182:9 | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 196:9 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 29:79 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 40:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 57:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 73:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 129:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 145:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 162:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 29:79 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 40:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 57:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 73:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 129:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 145:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 162:23 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:12 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:12 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:12 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 145:87 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 154:73 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 165:77 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 189:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 202:79 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 232:93 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:79 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 264:83 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 287:85 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 317:98 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 327:106 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 341:9 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 350:88 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 373:90 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 403:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 413:107 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 426:85 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 435:89 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 457:91 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 104:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 107:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 144:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 148:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 197:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 200:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 222:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 226:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 353:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 356:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 378:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 382:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 104:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 107:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 144:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 148:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 197:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 200:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 222:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 226:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 353:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 356:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 378:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 382:99 | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:54 | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:19 | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:54 | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:9 | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:19 | - |
| src/MediatR/NotificationHandlerExecutor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 7: | - |
| src/MediatR/NotificationPublishers/ForeachAwaitPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 17:90 | - |
| src/MediatR/NotificationPublishers/TaskWhenAllPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:84 | - |
| src/MediatR/Pipeline/IRequestExceptionAction.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestExceptionHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestExceptionHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:57 | - |
| src/MediatR/Pipeline/IRequestPostProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestPreProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:22 | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:52 | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:59 | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 31:40 | CompilationError |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:22 | - |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:46 | - |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:59 | - |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 32:40 | CompilationError |
| src/MediatR/Pipeline/RequestPostProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:59 | - |
| src/MediatR/Pipeline/RequestPreProcessorBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:59 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:72 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:82 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:42 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:71 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:9 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 96:9 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 192:98 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 298:103 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 310:13 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363: | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 387:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 387:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 435:64 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 42:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 43:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 44:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 47:57 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:100 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:136 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 54:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 58:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 59:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 61:38 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 62:56 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 112:61 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 114:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 139:48 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:43 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:72 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 281:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 284:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 316:29 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 317:28 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 326:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 42:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 43:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 44:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 47:57 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:100 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:136 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 54:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 58:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 59:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 61:38 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 62:56 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 112:61 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 114:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 139:48 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:43 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:72 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 281:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 284:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 316:29 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 317:28 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 326:73 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 12:33 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 12:61 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:33 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:61 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 21:29 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 22:51 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 21:29 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 22:51 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 11:58 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 17:44 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 17:73 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:39 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:57 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:64 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:44 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:73 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 34: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:64 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:39 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:57 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 55: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 14:70 | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:9 | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:9 | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 29: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:62 | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:9 | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 37: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 64: | - |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

