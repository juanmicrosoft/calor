# Serilog — Round-Trip Verification Report

**Calor Version:** 0.24.0
**Date:** 2026-10-07
**Duration:** 43.7s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `adae614b8fbc4db7a0ef118038d6187c`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 1
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 811 passed, 0 failed, 0 skipped |
| Files converted | 57/112 (50.9%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 32 |
| Build after replacement | Success |
| Round-trip tests | 811 passed, 0 failed, 0 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **50.9%** (57/112) |
| Converted natively (zero losses) | 44 (39.3%) |
| Converted with losses | 13 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 49 |
| Excluded by pattern (coverage failures in denominator) | 6 |
| Minimum total coverage | 30.0% |
| Minimum native coverage | 25.0% |
| Interop blocks (raw C# preserved) | 71 |
| Distinct semantic gaps | 0 |
| Loss ledger by kind | EmitterFallback: 1, InteropPreserved: 70 |

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 811/811 passed (1 TRX file(s))
- Round-trip: 811/811 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/Serilog/Capturing/DepthLimiter.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Capturing/PropertyBinder.cs | Compile Error | multi-context-divergent-preserve | 2 | 100% | 1 | 1 | - | Binding 'position' has no type annotation and no initializer. Add either ':type'... |
| src/Serilog/Capturing/PropertyValueConverter.cs | Compile Error | multi-context-divergent-preserve | 2 | 100% | 4 | 4 | - | Binding 'converted' has no type annotation and no initializer. Add either ':type... |
| src/Serilog/Capturing/TrimConfiguration.cs | Replaced | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | - |
| src/Serilog/Configuration/BatchingOptions.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Configuration/ILoggerSettings.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | No overload of internal call 'Sink' matches (OBJECT). Candidates: Serilog.Config... |
| src/Serilog/Context/EnricherStack.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 4 | 4 | - | Property 'Current' is already defined in 'Serilog.Context.EnricherStack.Enumerat... |
| src/Serilog/Context/LogContext.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | No overload of internal call 'Push' matches (OBJECT). Candidates: Serilog.Contex... |
| src/Serilog/Context/LogContextEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Constants.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/CustomDefaultMethodImplementationAttribute.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/EmptyEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/PropertyEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/SafeAggregateEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Filters/DelegateFilter.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/IBatchedLogEventSink.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/IDestructuringPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Core/ILogEventEnricher.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventFilter.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventPropertyFactory.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventPropertyValueFactory.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventSink.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/ILoggingFailureListener.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/IMessageTemplateParser.cs | Replaced | multi-context-identical-selected | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/IScalarConversionPolicy.cs | Replaced | multi-context-identical-selected | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/ISetLoggingFailureListener.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/LevelOverrideMap.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 1 | 1 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Core/LoggingFailureKind.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/MessageTemplateFormatMethodAttribute.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/ByReferenceStringComparer.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Core/PropertiesInlineArray.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Core/Sinks/AggregateSink.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Core/Sinks/Batching/BatchingSink.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/ConditionalSink.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/Sinks/DisposingAggregateSink.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/Sinks/Fallback/DelegatingLoggingFailureListener.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Core/Sinks/FilteringSink.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/OptionalInterfaceForwardingSink.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Core/Sinks/SafeAggregateSink.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Debugging/LoggingFailedException.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Debugging/SelfLog.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Events/DictionaryValue.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Events/EventProperty.cs | Replaced | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | - |
| src/Serilog/Events/LevelAlias.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Events/LogEvent.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 2 | 2 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Events/LogEventLevel.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Events/LogEventProperty.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Events/LogEventPropertyValue.cs | Replaced | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | - |
| src/Serilog/Events/MessageTemplate.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Events/ScalarValue.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Events/SequenceValue.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Events/StructureValue.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Filters/Matching.cs | Compile Error | multi-context-divergent-preserve | 2 | 100% | 3 | 3 | - | Binding 'propertyValue' has no type annotation and no initializer. Add either ':... |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | Compile Error | multi-context-divergent-preserve | 2 | 100% | 1 | 1 | - | Binding 'propertyValue' has no type annotation and no initializer. Add either ':... |
| src/Serilog/Formatting/Display/OutputProperties.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Formatting/ITextFormatter.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 3 | 3 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 17 | 17 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Guard.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/ILogger.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |
| src/Serilog/Log.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/LoggerConfiguration.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 1 | 1 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/LoggerExtensions.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Parsing/Alignment.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Parsing/AlignmentDirection.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Parsing/Destructuring.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | Binding 'propertyNameAndDestructuring' has no type annotation and no initializer... |
| src/Serilog/Parsing/MessageTemplateToken.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Parsing/PropertyToken.cs | Replaced | multi-context-identical-selected | 2 | 100% | 1 | 1 | - | - |
| src/Serilog/Parsing/TextToken.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 2 | 2 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/ByteMemoryScalarConversionPolicy.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/DelegateDestructuringPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/EnumScalarConversionPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/PrimitiveScalarConversionPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/ReflectionTypesScalarDestructuringPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Rendering/Casing.cs | Replaced | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 1 | 1 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Rendering/Padding.cs | Emit Compilation Error | multi-context-divergent-preserve | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip/Serilog/b8b526c... |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 10 | 10 | - | Binding 'minimumLevelControlledByLevelSwitchName' has no type annotation and no ... |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | Compile Error | multi-context-identical-selected | 2 | 100% | 3 | 3 | - | Binding 'accessorTypeName' has no type annotation and no initializer. Add either... |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | Emit Compilation Error | multi-context-identical-selected | 2 | 100% | 0 | 0 | - | /private/var/folders/61/_j3z01s52cz0rgb1z_v9mydr0000gn/T/calor-roundtrip-validat... |
| src/Serilog/Util/TimeProvider.cs | Replaced | multi-context-divergent-preserve | 2 | 0% | 1 | 1 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| src/Serilog/Capturing/DepthLimiter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:73 | - |
| src/Serilog/Capturing/DepthLimiter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:16 | - |
| src/Serilog/Capturing/DepthLimiter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:9 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:14 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:14 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:37 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:49 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:102 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:12 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:12 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 12:31 | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 12:31 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:14 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:27 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:48 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:81 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:51 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:77 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:46 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:72 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 121:13 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:37 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 127:5 | - |
| src/Serilog/Capturing/PropertyBinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyBinder.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 30:13 | CompilationError |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 23: | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:14 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:12 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 89:12 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:69 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:12 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:5 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 121:62 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 121:5 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 172:45 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 172:56 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 189: | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 172: | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:43 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:86 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:5 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 297:45 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 297:56 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 356:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 357:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 385:5 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 402:41 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 414:17 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 428:42 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 437:142 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 437:14 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 448:9 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 516:50 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 110:13 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 116:15 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 120:11 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 123:11 | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 126:11 | - |
| src/Serilog/Capturing/TrimConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 13: | - |
| src/Serilog/Configuration/BatchingOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:12 | - |
| src/Serilog/Configuration/BatchingOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 53:12 | - |
| src/Serilog/Configuration/ILoggerSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Configuration/ILoggerSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:20 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:43 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:84 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:12 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:12 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 77:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 76:12 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 96:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:9 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:12 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 8:34 | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 8:34 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:14 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:41 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 109:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 125:55 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 125:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 149:9 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 147:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 167:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 199:12 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 76:23 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 77:23 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 92:23 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 76:23 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 77:23 | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 92:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:14 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:9 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:9 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:37 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:69 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 114:40 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 114:71 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 114:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 130:40 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 130:72 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 130:12 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 150:9 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 151:9 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:19 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 178:9 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 64:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 76:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 88:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0119 | Error | 113:32 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 64:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 76:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 88:23 | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0119 | Error | 113:32 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:14 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:9 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:9 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:12 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:12 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:44 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:12 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:48 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:12 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 40:44 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 41:23 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 40:44 | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 41:23 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:14 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:14 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:14 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:46 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:87 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:9 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:52 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:35 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:45 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 67:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 87:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 101:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 114:56 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 114:12 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 135:56 | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 135:12 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:42 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:41 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:12 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:46 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:12 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:39 | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:5 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:14 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:14 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:38 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:79 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 46:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 118:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 116:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 142:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 140:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 163:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 164:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 162:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 172:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 197:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 198:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 196:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 219:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 216:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:44 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:76 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 243:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 269:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 267:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 276:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 283:13 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 302:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 303:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 301:12 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 308:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 331:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 332:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 333:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 329:19 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 336:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 352:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 353:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 351:19 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 358:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 360:9 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 377:44 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 377:19 | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 157:12 | CompilationError |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 173:20 | CompilationError |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 179:12 | CompilationError |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 192:12 | CompilationError |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:40 | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:5 | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:5 | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:31 | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 53:12 | - |
| src/Serilog/Context/EnricherStack.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:16 | - |
| src/Serilog/Context/EnricherStack.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 55:9 | CompilationError |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:21 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:36 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:9 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 110:43 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 110:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 112:9 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 136:43 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 136:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 140:9 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 158:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 160:9 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:19 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 171:9 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 190:12 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 201:33 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 201:52 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 215:18 | - |
| src/Serilog/Context/LogContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:37 | - |
| src/Serilog/Context/LogContext.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 49:12 | CompilationError |
| src/Serilog/Context/LogContextEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:24 | - |
| src/Serilog/Context/LogContextEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:43 | - |
| src/Serilog/Core/CustomDefaultMethodImplementationAttribute.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/CustomDefaultMethodImplementationAttribute.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 18:11 | - |
| src/Serilog/Core/CustomDefaultMethodImplementationAttribute.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 18:11 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:14 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:32 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:59 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:24 | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:43 | - |
| src/Serilog/Core/Enrichers/EmptyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:24 | - |
| src/Serilog/Core/Enrichers/EmptyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:43 | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:37 | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:24 | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:43 | - |
| src/Serilog/Core/Enrichers/PropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:24 | - |
| src/Serilog/Core/Enrichers/PropertyEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:43 | - |
| src/Serilog/Core/Enrichers/SafeAggregateEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:34 | - |
| src/Serilog/Core/Enrichers/SafeAggregateEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:24 | - |
| src/Serilog/Core/Enrichers/SafeAggregateEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:43 | - |
| src/Serilog/Core/Filters/DelegateFilter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Filters/DelegateFilter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:27 | - |
| src/Serilog/Core/Filters/DelegateFilter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:27 | - |
| src/Serilog/Core/IBatchedLogEventSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 24: | - |
| src/Serilog/Core/IDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/IDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:39 | - |
| src/Serilog/Core/IDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:104 | - |
| src/Serilog/Core/IDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:104 | - |
| src/Serilog/Core/ILogEventEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILogEventEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:17 | - |
| src/Serilog/Core/ILogEventEnricher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:36 | - |
| src/Serilog/Core/ILogEventFilter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILogEventFilter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:20 | - |
| src/Serilog/Core/ILogEventPropertyFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILogEventPropertyFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:5 | - |
| src/Serilog/Core/ILogEventPropertyValueFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILogEventPropertyValueFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 18:5 | - |
| src/Serilog/Core/ILogEventSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILogEventSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:15 | - |
| src/Serilog/Core/ILoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ILoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:9 | - |
| src/Serilog/Core/IMessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 17: | - |
| src/Serilog/Core/IScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 7: | - |
| src/Serilog/Core/ISetLoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/ISetLoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:29 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:46 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:16 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:9 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:9 | - |
| src/Serilog/Core/LevelOverrideMap.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 60: | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 12:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 13:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 14:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 16:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 17:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 18:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 12:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 13:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 14:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 16:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 17:23 | - |
| src/Serilog/Core/LevelOverrideMap.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 18:23 | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:31 | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:12 | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 21:38 | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 21:38 | - |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:47 | - |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:71 | - |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:12 | - |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:12 | - |
| src/Serilog/Core/Pipeline/ByReferenceStringComparer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:14 | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:33 | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:31 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:31 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:31 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:12 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:23 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:23 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:26 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:31 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:35 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:23 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 53:23 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:26 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:31 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 65:35 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 69:23 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:27 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 552:101 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 552:195 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 565:105 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 552:101 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 552:195 | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 565:105 | - |
| src/Serilog/Core/PropertiesInlineArray.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Core/PropertiesInlineArray.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 35:11 | - |
| src/Serilog/Core/PropertiesInlineArray.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 35:11 | - |
| src/Serilog/Core/Sinks/AggregateSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:26 | - |
| src/Serilog/Core/Sinks/AggregateSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:22 | - |
| src/Serilog/Core/Sinks/AggregateSink.cs | project-candidate-validation | MSBuildReportedLocation | CS0019 | Error | 20:30 | - |
| src/Serilog/Core/Sinks/AggregateSink.cs | project-candidate-validation | MSBuildReportedLocation | CS0019 | Error | 20:30 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:21 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:21 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:14 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:14 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:39 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:68 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:41 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:70 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:95 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:9 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:9 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:12 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:13 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:13 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 104:13 | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 107:13 | - |
| src/Serilog/Core/Sinks/Fallback/DelegatingLoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 17:47 | - |
| src/Serilog/Core/Sinks/Fallback/DelegatingLoggingFailureListener.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:48 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:14 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:32 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:53 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:22 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 23:103 | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 23:103 | - |
| src/Serilog/Core/Sinks/FilteringSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Core/Sinks/FilteringSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:26 | - |
| src/Serilog/Core/Sinks/FilteringSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:46 | - |
| src/Serilog/Core/Sinks/FilteringSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:22 | - |
| src/Serilog/Core/Sinks/SafeAggregateSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:30 | - |
| src/Serilog/Core/Sinks/SafeAggregateSink.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:22 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:77 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:24 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:79 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:24 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:80 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 81:24 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:81 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 119:24 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:82 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:24 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 119:57 | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 119:57 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 45:51 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:63 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:65 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 86:66 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:67 | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 105:67 | - |
| src/Serilog/Debugging/SelfLog.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:31 | - |
| src/Serilog/Debugging/SelfLog.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:31 | - |
| src/Serilog/Debugging/SelfLog.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 82:52 | - |
| src/Serilog/Debugging/SelfLog.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 87: | - |
| src/Serilog/Debugging/SelfLog.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 103:19 | - |
| src/Serilog/Debugging/SelfLog.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 15:23 | - |
| src/Serilog/Debugging/SelfLog.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 42:26 | - |
| src/Serilog/Debugging/SelfLog.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 15:23 | - |
| src/Serilog/Debugging/SelfLog.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 42:26 | - |
| src/Serilog/Events/DictionaryValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:28 | - |
| src/Serilog/Events/DictionaryValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:12 | - |
| src/Serilog/Events/DictionaryValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:33 | - |
| src/Serilog/Events/DictionaryValue.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 12:23 | - |
| src/Serilog/Events/DictionaryValue.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 13:23 | - |
| src/Serilog/Events/DictionaryValue.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 12:23 | - |
| src/Serilog/Events/DictionaryValue.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 13:23 | - |
| src/Serilog/Events/EventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37:12 | - |
| src/Serilog/Events/EventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 47:39 | - |
| src/Serilog/Events/EventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:50 | - |
| src/Serilog/Events/LevelAlias.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:18 | - |
| src/Serilog/Events/LevelAlias.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:18 | - |
| src/Serilog/Events/LevelAlias.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:18 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:14 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:5 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:5 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:21 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:47 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:90 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:123 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:21 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:47 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:90 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:123 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:165 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 75:190 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:23 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:49 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:92 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:153 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 84:178 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:12 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:12 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 116:12 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:31 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 142:12 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 154:37 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 166:42 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 178:37 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 195:42 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 217:37 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 264:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 265:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 267:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 269:9 | - |
| src/Serilog/Events/LogEvent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 270:9 | - |
| src/Serilog/Events/LogEvent.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 91:266 | - |
| src/Serilog/Events/LogEvent.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 107:254 | - |
| src/Serilog/Events/LogEvent.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 91:266 | - |
| src/Serilog/Events/LogEvent.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 107:254 | - |
| src/Serilog/Events/LogEventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:42 | - |
| src/Serilog/Events/LogEventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:31 | - |
| src/Serilog/Events/LogEventProperty.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:12 | - |
| src/Serilog/Events/LogEventProperty.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 50:49 | - |
| src/Serilog/Events/LogEventProperty.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 50:49 | - |
| src/Serilog/Events/LogEventPropertyValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:33 | - |
| src/Serilog/Events/LogEventPropertyValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52: | - |
| src/Serilog/Events/LogEventPropertyValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 52: | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 33:28 | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48:41 | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111:12 | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 129: | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 129: | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 147:24 | - |
| src/Serilog/Events/MessageTemplate.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 147:87 | - |
| src/Serilog/Events/MessageTemplate.cs | project-candidate-validation | MSBuildReportedLocation | CS0030 | Error | 61:51 | - |
| src/Serilog/Events/MessageTemplate.cs | project-candidate-validation | MSBuildReportedLocation | CS0030 | Error | 61:51 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:33 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:48 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:45 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:54 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:122 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 122:53 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 122:88 | - |
| src/Serilog/Events/ScalarValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 124:9 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 83:41 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 84:52 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 84:17 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 83:41 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 84:52 | - |
| src/Serilog/Events/ScalarValue.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 84:17 | - |
| src/Serilog/Events/SequenceValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/SequenceValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:26 | - |
| src/Serilog/Events/SequenceValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:12 | - |
| src/Serilog/Events/SequenceValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 61:33 | - |
| src/Serilog/Events/SequenceValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 32:27 | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:12 | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 68:33 | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:24 | - |
| src/Serilog/Events/StructureValue.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 95:43 | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:19 | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 39: | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 59:19 | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:19 | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79: | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:83 | - |
| src/Serilog/Filters/Matching.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:19 | - |
| src/Serilog/Filters/Matching.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 43:13 | CompilationError |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:42 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:60 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:60 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 11:61 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 12:61 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 13:61 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 11:61 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 12:61 | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0266 | Error | 13:61 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 31:14 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:24 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:43 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 71:17 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 141:25 | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 65:17 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:21 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:31 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:57 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:120 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:152 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:46 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 15:27 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 16:68 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 16:125 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 17:27 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:68 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:125 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 19:27 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 15:27 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 16:68 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 16:125 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 17:27 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:68 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:125 | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 19:27 | - |
| src/Serilog/Formatting/ITextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/ITextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:17 | - |
| src/Serilog/Formatting/ITextFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:36 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:14 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:24 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 55:43 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:13 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 133:32 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 133:96 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 133:159 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 135: | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 133: | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 64:30 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 65:28 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 66:67 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 64:30 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 65:28 | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 66:67 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:24 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 43:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:46 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58:64 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:48 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:66 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:49 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:67 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 135:50 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 135:68 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 162:62 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 298:48 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 303:47 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 312:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 322:49 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 331:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 341:52 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 344:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 354:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 357:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 367:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 370:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 380:54 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 383:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 393:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 396:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 406:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 409:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 419:54 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 422:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 432:54 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 435:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 445:55 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 448:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 458:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 458:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 463:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 475:43 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 475:65 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 480:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 492:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 492:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 496:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 509:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 509:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 513:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 522:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 522:53 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 526:9 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 537:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 544:47 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 549:33 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 559:58 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 174:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 175:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 178:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 179:43 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 183:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 187:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 188:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 191:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 192:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 208:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 209:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 209:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 227:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 228:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 228:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 242:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 243:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 243:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 257:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 258:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 258:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 272:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 273:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 273:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 287:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 288:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 288:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 302:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 303:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 303:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 317:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 318:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 318:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 332:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 333:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 333:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 347:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 348:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 348:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 362:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 363:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 363:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 378:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 379:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 379:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 395:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 396:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 396:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 412:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 413:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 413:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 429:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 430:27 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0165 | Error | 430:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 440:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 441:27 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0165 | Error | 441:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 482:38 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 174:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 175:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 178:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 179:43 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 183:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 187:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 188:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 191:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 192:37 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 208:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 209:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 209:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 227:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 228:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 228:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 242:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 243:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 243:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 257:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 258:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 258:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 272:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 273:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 273:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 287:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 288:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 288:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 302:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 303:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 303:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 317:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 318:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 318:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 332:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 333:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 333:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 347:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 348:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 348:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 362:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 363:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 363:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 378:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 379:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 379:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 395:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 396:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 396:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 412:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0841 | Error | 413:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0815 | Error | 413:17 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 429:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 430:27 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0165 | Error | 430:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 440:41 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 441:27 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0165 | Error | 441:56 | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 482:38 | - |
| src/Serilog/Guard.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Guard.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 10:101 | - |
| src/Serilog/Guard.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 10:101 | - |
| src/Serilog/ILogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/ILogger.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 36: | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:12 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 53:9 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64:9 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 82:38 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 82:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 101:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 112:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 120:38 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 120:19 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 126:30 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 137:30 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 149:33 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 162:38 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 176:42 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 188:30 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 200:30 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 213:33 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 227:38 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 242:42 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 255:30 | - |
| src/Serilog/Log.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 266:34 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 696:107 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 696:201 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 703:111 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 696:107 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 696:201 | - |
| src/Serilog/Log.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 703:111 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 25:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 26:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29:14 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 30:5 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 70:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 89:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 99:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 117:12 | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/LoggerConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 127: | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 17:59 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 18:56 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 19:59 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 20:55 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 21:58 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 22:65 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 23:84 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 27:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 36:40 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 36:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 44:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 50:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 52:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 53:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 63:25 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 64:23 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 66:25 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 67:22 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 17:59 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 18:56 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 19:59 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 20:55 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 21:58 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 22:65 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 23:84 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 27:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 36:40 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 36:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 44:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 50:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 52:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 53:29 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 63:25 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 64:23 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 66:25 | - |
| src/Serilog/LoggerConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS1729 | Error | 67:22 | - |
| src/Serilog/LoggerExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:14 | - |
| src/Serilog/LoggerExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:9 | - |
| src/Serilog/LoggerExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:19 | - |
| src/Serilog/Parsing/Alignment.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 27:22 | - |
| src/Serilog/Parsing/Alignment.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 36:12 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 23:21 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:12 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48:5 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 60:13 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 68:13 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 77:5 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 244:53 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 263:12 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 279:9 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 58:11 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 59:11 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 60:11 | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 128:13 | - |
| src/Serilog/Parsing/MessageTemplateToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:33 | - |
| src/Serilog/Parsing/MessageTemplateToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:96 | - |
| src/Serilog/Parsing/PropertyToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 34:118 | - |
| src/Serilog/Parsing/PropertyToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42: | - |
| src/Serilog/Parsing/PropertyToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:33 | - |
| src/Serilog/Parsing/PropertyToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:96 | - |
| src/Serilog/Parsing/PropertyToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:12 | - |
| src/Serilog/Parsing/TextToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:33 | - |
| src/Serilog/Parsing/TextToken.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 44:96 | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 35:13 | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:63 | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:63 | - |
| src/Serilog/Policies/ByteMemoryScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Policies/ByteMemoryScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 74:11 | - |
| src/Serilog/Policies/ByteMemoryScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS8955 | Error | 74:11 | - |
| src/Serilog/Policies/DelegateDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:46 | - |
| src/Serilog/Policies/DelegateDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:111 | - |
| src/Serilog/Policies/DelegateDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:111 | - |
| src/Serilog/Policies/EnumScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:63 | - |
| src/Serilog/Policies/EnumScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:63 | - |
| src/Serilog/Policies/PrimitiveScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:63 | - |
| src/Serilog/Policies/PrimitiveScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:63 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:14 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:41 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:68 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:46 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 38:9 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 23:111 | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 23:111 | - |
| src/Serilog/Policies/ReflectionTypesScalarDestructuringPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:46 | - |
| src/Serilog/Policies/ReflectionTypesScalarDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:111 | - |
| src/Serilog/Policies/ReflectionTypesScalarDestructuringPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 11:111 | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:14 | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 21:41 | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 21:63 | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 21:63 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 19:21 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:31 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:64 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:127 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:40 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 52:54 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57: | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 57: | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:29 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 92:91 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 55:71 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 56:26 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 55:71 | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 56:26 | - |
| src/Serilog/Rendering/Padding.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 24:30 | - |
| src/Serilog/Rendering/Padding.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Rendering/Padding.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:30 | - |
| src/Serilog/Rendering/Padding.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 56:49 | - |
| src/Serilog/Rendering/Padding.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 13:51 | - |
| src/Serilog/Rendering/Padding.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 13:51 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:64 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:111 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 20:21 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 5:28 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 6:33 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 7:33 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 5:28 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 6:33 | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 7:33 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 54:21 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 63:21 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 72:14 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 78:33 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 83:27 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:9 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 93: | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 94: | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 102:13 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 108:13 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115:13 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 123:17 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 130:9 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 148:13 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 165:103 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 165:12 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 169:9 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 188:13 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 204:69 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 204:12 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 216:67 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 216:78 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 227:33 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 227:94 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 227:161 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 245: | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 225: | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 257:59 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 257:114 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 261: | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:71 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 268:21 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 58:11 | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 129:11 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 22:12 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 24: | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:55 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:13 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 103:25 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 126:13 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 143:13 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 39:13 | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 40:13 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 28:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 40:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 42:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 39:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 50:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 51:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:46 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:107 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 57:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:56 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 62:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 67:46 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 68:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 67:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:50 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 74:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 73:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:66 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 79:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:56 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 85:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:63 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 91:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:46 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 98:9 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 97:21 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:88 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:118 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:127 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:88 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:118 | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 12:127 | - |
| src/Serilog/Util/TimeProvider.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

