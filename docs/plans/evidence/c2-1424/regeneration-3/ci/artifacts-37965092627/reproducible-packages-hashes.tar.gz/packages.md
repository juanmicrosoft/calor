| Published file | A SHA-256 | B SHA-256 | Same |
|---|---|---|---|
| `Calor.Sdk.0.24.0.nupkg` | `157fc9cab9db1fe095c0b77a9ff264c8ea6186585bea6b964fb53afed41053bb` | `157fc9cab9db1fe095c0b77a9ff264c8ea6186585bea6b964fb53afed41053bb` | yes |
| `calor.0.24.0.nupkg` | `d59aea56abb0e89125805686c59b616e47614ecea9a1c9b5fcbc9fb929401cc5` | `d59aea56abb0e89125805686c59b616e47614ecea9a1c9b5fcbc9fb929401cc5` | yes |
| `calor-nuget-04e61f188e85a710a91242e1ddbf35fcd50e329e.provenance.json` | `1f00791f712d85811ab9ad3906dbba87eb1724957068ce3645d3dff1450af79d` | `1f00791f712d85811ab9ad3906dbba87eb1724957068ce3645d3dff1450af79d` | yes |
| `calor-nuget-04e61f188e85a710a91242e1ddbf35fcd50e329e.sbom.spdx.json` | `eb2abecab68965c07cf0e41d99cd268b8a8c7c06494971aa046dd6c48cd1d9e3` | `eb2abecab68965c07cf0e41d99cd268b8a8c7c06494971aa046dd6c48cd1d9e3` | yes |

Package entries compared (content hash and zip timestamp): 97.
Differences: 0.

Toolchains:
- A: {"dotnet": "10.0.401", "dotnetSdkBuild": "sha256:a5b223b4a6d67e85e803b56f2fc5fb52b042f2c27a73e872c3c899dd21bd8465", "node": "v22.23.3", "npm": "10.9.9", "os": "Linux x86_64"}
- B: {"dotnet": "10.0.401", "dotnetSdkBuild": "sha256:a5b223b4a6d67e85e803b56f2fc5fb52b042f2c27a73e872c3c899dd21bd8465", "node": "v22.23.3", "npm": "10.9.9", "os": "Linux x86_64"}
