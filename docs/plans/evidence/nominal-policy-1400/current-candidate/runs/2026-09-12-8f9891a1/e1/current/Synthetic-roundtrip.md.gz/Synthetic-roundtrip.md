# Synthetic — Round-Trip Verification Report

**Calor Version:** 0.21.0
**Date:** 2026-09-12
**Duration:** 20.7s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `0e2f464508f44ebc9af01e6d41c30a32`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 2
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 52 passed, 0 failed, 0 skipped |
| Files converted | 5/5 (100.0%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 0 |
| Build after replacement | Success |
| Round-trip tests | 52 passed, 0 failed, 0 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **100.0%** (5/5) |
| Converted natively (zero losses) | 5 (100.0%) |
| Converted with losses | 0 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 0 |
| Excluded by pattern (coverage failures in denominator) | 0 |
| Minimum total coverage | 62.5% |
| Minimum native coverage | 62.5% |
| Interop blocks (raw C# preserved) | 0 |
| Distinct semantic gaps | 0 |

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 52/52 passed (1 TRX file(s))
- Round-trip: 52/52 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| SyntheticLib/Calculator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| SyntheticLib/DateHelper.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| SyntheticLib/FizzBuzz.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| SyntheticLib/StringUtils.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| SyntheticLib/Temperature.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| SyntheticLib/Calculator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| SyntheticLib/FizzBuzz.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| SyntheticLib/FizzBuzz.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| SyntheticLib/FizzBuzz.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| SyntheticLib/FizzBuzz.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 11:12 | AnalysisOnly |
| SyntheticLib/FizzBuzz.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 31:15 | Uncataloged |
| SyntheticLib/StringUtils.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 6:30 | AnalysisOnly |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 14:30 | AnalysisOnly |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 16:25 | AnalysisOnly |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:29 | AnalysisOnly |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:30 | AnalysisOnly |
| SyntheticLib/StringUtils.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 49:14 | AnalysisOnly |
| SyntheticLib/Temperature.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:30 | AnalysisOnly |
| SyntheticLib/Temperature.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:30 | AnalysisOnly |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

