# MediatR — Round-Trip Verification Report

**Calor Version:** 0.21.0
**Date:** 2026-09-12
**Duration:** 62.9s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `0a97eaacffab4ad19bd65764d7174fae`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 2
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 155 passed, 0 failed, 2 skipped |
| Files converted | 24/32 (75.0%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 7 |
| Build after replacement | Success |
| Round-trip tests | 155 passed, 0 failed, 2 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **75.0%** (24/32) |
| Converted natively (zero losses) | 18 (56.2%) |
| Converted with losses | 6 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 8 |
| Excluded by pattern (coverage failures in denominator) | 0 |
| Minimum total coverage | 55.0% |
| Minimum native coverage | 40.0% |
| Interop blocks (raw C# preserved) | 11 |
| Distinct semantic gaps | 0 |
| Loss ledger by kind | InteropPreserved: 11 |

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 155/157 passed (1 TRX file(s))
- Round-trip: 155/157 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/MediatR/IMediator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/INotificationHandler.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/INotificationPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Internal/HandlersOrderer.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/Internal/ObjectDetails.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/IPipelineBehavior.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/MediatR/IPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/IRequestHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/ISender.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/IStreamPipelineBehavior.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/MediatR/IStreamRequestHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Mediator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/MicrosoftExtensionsDI/RequestExceptionActionProcessorStrategy.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/MicrosoftExtensionsDI/ServiceCollectionExtensions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/NotificationHandlerExecutor.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/MediatR/NotificationPublishers/ForeachAwaitPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/NotificationPublishers/TaskWhenAllPublisher.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestExceptionAction.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestExceptionHandler.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestPostProcessor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/IRequestPreProcessor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'GetExceptionTypes' matches (OBJECT). Candidates: M... |
| src/MediatR/Pipeline/RequestExceptionHandlerState.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'GetExceptionTypes' matches (OBJECT). Candidates: M... |
| src/MediatR/Pipeline/RequestPostProcessorBehavior.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Pipeline/RequestPreProcessorBehavior.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/MediatR/Registration/ServiceRegistrar.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 2 | 2 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/TypeForwardings.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | Replaced | single-context-selected | 1 | 100% | 2 | 2 | - | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | Replaced | single-context-selected | 1 | 100% | 3 | 3 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| src/MediatR/IMediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/INotificationHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/INotificationHandler.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 16:60 | - |
| src/MediatR/INotificationHandler.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 16:60 | - |
| src/MediatR/INotificationHandler.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:12 | AnalysisOnly |
| src/MediatR/INotificationPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 12: | - |
| src/MediatR/IPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IPublisher.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/ISender.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IStreamPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 12: | - |
| src/MediatR/IStreamPipelineBehavior.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/IStreamRequestHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0026 | Error | 17:30 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:52 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:84 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 60:41 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0026 | Error | 17:30 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:52 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS1061 | Error | 49:84 | - |
| src/MediatR/Internal/HandlersOrderer.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 60:41 | - |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 11:23 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:63 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 20:32 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:32 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:35 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:55 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:89 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:33 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:78 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:31 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:65 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 62:33 | AnalysisOnly |
| src/MediatR/Internal/HandlersOrderer.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 63:60 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:26 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:26 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:41 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:46 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:82 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:87 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:118 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0274 | Error | 30:123 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:28 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:61 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:28 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:61 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:28 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:61 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:12 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:41 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:51 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:62 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:73 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:84 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:32 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:73 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:35 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:74 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:32 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:70 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:12 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:41 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:51 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:62 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:73 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:84 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 67:41 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 67:82 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:44 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:83 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:28 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:45 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:28 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:45 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:22 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:30 | AnalysisOnly |
| src/MediatR/Internal/ObjectDetails.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:33 | AnalysisOnly |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 29:79 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 40:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 79:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 138:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 177:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 29:79 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 40:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 79:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 138:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:23 | - |
| src/MediatR/Mediator.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 177:23 | - |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:32 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:32 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 77:32 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:33 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:63 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:47 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 88:49 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 93:38 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 103:15 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 111:37 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 121:14 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 148:70 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 148:15 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 155:32 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 175:32 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 178:63 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 181:47 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 183:36 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 193:22 | AnalysisOnly |
| src/MediatR/Mediator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:14 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 104:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 107:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 144:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 148:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 197:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 200:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 222:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 226:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 353:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 356:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 378:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 382:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 104:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 107:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 144:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 148:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 197:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 200:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 222:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 226:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 353:95 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 356:101 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 378:54 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 382:99 | - |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:45 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 106:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 137:23 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 140:53 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 145:27 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 147:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 199:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 215:23 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 218:53 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 223:27 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 225:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 277:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 293:23 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 296:53 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 301:27 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 303:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 355:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 371:23 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 374:53 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 379:27 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 381:24 | AnalysisOnly |
| src/MediatR/MicrosoftExtensionsDI/MediatrServiceConfiguration.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/NotificationHandlerExecutor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 7: | - |
| src/MediatR/Pipeline/IRequestExceptionAction.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestExceptionHandler.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestPostProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/IRequestPreProcessor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 31:40 | CompilationError |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 31:40 | CompilationError |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:56 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:120 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:91 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:70 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:45 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionActionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:33 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 32:40 | CompilationError |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 32:40 | CompilationError |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:57 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 34:122 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:92 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:70 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:24 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:25 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:26 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:41 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:14 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:45 | AnalysisOnly |
| src/MediatR/Pipeline/RequestExceptionProcessorBehavior.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 61:33 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 310:13 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 363: | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 42:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 43:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 44:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 47:57 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:100 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:136 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 54:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 58:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 59:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 61:38 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 62:56 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 112:61 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 114:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 139:48 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:43 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:72 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 281:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 284:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 316:29 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 317:28 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 326:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 42:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 43:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 44:53 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 47:57 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:100 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 48:136 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 54:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 58:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 59:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 60:32 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 61:38 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 62:56 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 112:61 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 114:44 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 139:48 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:43 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 260:72 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 281:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 284:23 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 290:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 291:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 293:114 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:69 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 294:120 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 297:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 302:102 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 316:29 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 317:28 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | project-candidate-validation | MSBuildReportedLocation | CS0305 | Error | 326:73 | - |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:42 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:33 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:45 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:37 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:67 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:20 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:20 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 61:56 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 62:38 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 66:55 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:75 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:104 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 85:73 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:53 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 92:48 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 94:39 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 111:27 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 112:61 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 114:18 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 117:39 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 127:40 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 127:67 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 129:20 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 130:87 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 134:77 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 139:55 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 141:63 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 147:210 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 149:60 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 160:61 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 160:77 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 164:61 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 164:77 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 171:32 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 174:20 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 175:14 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 190:60 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 193:53 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 197:60 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 200:30 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 220:43 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 235:23 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 236:31 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 240:36 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 247:16 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 247:45 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 254:36 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 259:20 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 260:77 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 262:17 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 262:82 | Uncataloged |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 263:18 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 264:24 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 266:78 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 270:19 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 270:39 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 279:87 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 279:138 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 282:96 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 285:99 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 287:69 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 287:116 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 287:186 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 287:236 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 287:340 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 289:24 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 289:85 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 297:141 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 299:41 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 302:142 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 304:41 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 305:46 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 307:46 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 314:56 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 316:48 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 317:50 | AnalysisOnly |
| src/MediatR/Registration/ServiceRegistrar.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 326:115 | AnalysisOnly |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 21:29 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 22:51 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 21:29 | - |
| src/MediatR/Wrappers/NotificationHandlerWrapper.cs | project-candidate-validation | MSBuildReportedLocation | CS0411 | Error | 22:51 | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 37: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 34: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 58: | - |
| src/MediatR/Wrappers/RequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 55: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 29: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 29: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 41: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 37: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 64: | - |
| src/MediatR/Wrappers/StreamRequestHandlerWrapper.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 64: | - |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

