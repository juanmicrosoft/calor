# Serilog — Round-Trip Verification Report

**Calor Version:** 0.21.0
**Date:** 2026-09-12
**Duration:** 48.6s
**Verdict:** FAIL — evidence: System.InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.RestoreParseContextGraphAsync(String workDir, String project, IReadOnlyDictionary`2 globalProperties, RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 597
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.ResolveAsync(String workDir, RoundTripConfig config, IReadOnlyCollection`1 candidateFiles, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 190
   at Calor.RoundTrip.Harness.RoundTripPipeline.ConvertAndReplaceAsync(String workDir, RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 508
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunCoreAsync(RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 88
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunAsync(RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 45; InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]; baseline build failed or was not run; round-trip build failed or was not run; test comparison is Incomplete; fidelity dimensions are missing
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `1db91e74a6f7423fa812a48c5f86a388`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 2
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.
- System.InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.RestoreParseContextGraphAsync(String workDir, String project, IReadOnlyDictionary`2 globalProperties, RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 597
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.ResolveAsync(String workDir, RoundTripConfig config, IReadOnlyCollection`1 candidateFiles, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 190
   at Calor.RoundTrip.Harness.RoundTripPipeline.ConvertAndReplaceAsync(String workDir, RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 508
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunCoreAsync(RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 88
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunAsync(RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 45

**Blocking gate failures:**
- evidence: System.InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.RestoreParseContextGraphAsync(String workDir, String project, IReadOnlyDictionary`2 globalProperties, RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 597
   at Calor.RoundTrip.Harness.ProjectParseContextResolver.ResolveAsync(String workDir, RoundTripConfig config, IReadOnlyCollection`1 candidateFiles, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/ProjectParseContextResolver.cs:line 190
   at Calor.RoundTrip.Harness.RoundTripPipeline.ConvertAndReplaceAsync(String workDir, RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 508
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunCoreAsync(RoundTripConfig config, RoundTripReport report, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 88
   at Calor.RoundTrip.Harness.RoundTripPipeline.RunAsync(RoundTripConfig config, CancellationToken cancellationToken) in /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/worktrees/d1-annotated-8f/tools/Calor.RoundTrip.Harness/RoundTripPipeline.cs:line 45
- InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
- baseline build failed or was not run
- round-trip build failed or was not run
- test comparison is Incomplete
- fidelity dimensions are missing

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 0 passed, 0 failed, 0 skipped |
| Files converted | 0/112 (0.0%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 0 |
| Regressions | **0** |

## Fidelity — INCONCLUSIVE

No coverage fraction is reported: InvalidOperationException: Could not restore parse-context graph '/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj': /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301: Unable to load the service index for source https://api.nuget.org/v3/index.json. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   The SSL connection could not be established, see inner exception. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Unable to read data from the transport connection: Socket is not connected. [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]
/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/src/Serilog/Serilog.csproj : error NU1301:   Socket is not connected [/Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/files/d1-current-evidence/shadow-annotated/e1-run1/runtime/calor-roundtrip/Serilog/d5dd501b/test/Serilog.Tests/Serilog.Tests.csproj]

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/Serilog/Capturing/DepthLimiter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Capturing/MessageTemplateProcessor.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Capturing/PropertyBinder.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Capturing/PropertyValueConverter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Capturing/TrimConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/BatchingOptions.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/ILoggerSettings.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerAuditSinkConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerDestructuringConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerEnrichmentConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerFilterConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerMinimumLevelConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerSettingsConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Configuration/LoggerSinkConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Context/EnricherStack.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Context/LogContext.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Context/LogContextEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Constants.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/CustomDefaultMethodImplementationAttribute.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/ConditionalEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/EmptyEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/FixedPropertyEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/PropertyEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Enrichers/SafeAggregateEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Filters/DelegateFilter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/IBatchedLogEventSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/IDestructuringPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventEnricher.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventFilter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventPropertyFactory.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventPropertyValueFactory.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILogEventSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ILoggingFailureListener.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/IMessageTemplateParser.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/IScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/ISetLoggingFailureListener.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/LevelOverrideMap.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/LoggingFailureKind.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/LoggingLevelSwitch.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/LoggingLevelSwitchChangedEventArgs.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/MessageTemplateFormatMethodAttribute.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/ByReferenceStringComparer.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/MessageTemplateCache.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Pipeline/SilentLogger.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/PropertiesInlineArray.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/AggregateSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/Batching/BatchingSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/Batching/FailureAwareBatchScheduler.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/ConditionalSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/DisposingAggregateSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/Fallback/DelegatingLoggingFailureListener.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/Fallback/FailureListenerSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/FilteringSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/OptionalInterfaceForwardingSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Core/Sinks/SafeAggregateSink.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Data/LogEventPropertyValueRewriter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Data/LogEventPropertyValueVisitor.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Debugging/LoggingFailedException.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Debugging/SelfLog.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/DictionaryValue.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/EventProperty.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/LevelAlias.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/LogEvent.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/LogEventLevel.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/LogEventProperty.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/LogEventPropertyValue.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/MessageTemplate.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/ScalarValue.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/SequenceValue.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Events/StructureValue.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Filters/Matching.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Display/LevelOutputFormat.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Display/MessageTemplateTextFormatter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Display/OutputProperties.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Display/PropertiesOutputFormat.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/ITextFormatter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Json/JsonFormatter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Formatting/Json/JsonValueFormatter.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Guard.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/ILogger.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Log.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/LoggerConfiguration.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/LoggerExtensions.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/Alignment.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/AlignmentDirection.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/Destructuring.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/MessageTemplateParser.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/MessageTemplateToken.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/PropertyToken.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Parsing/TextToken.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/ByteArrayScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/ByteMemoryScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/DelegateDestructuringPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/EnumScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/PrimitiveScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/ProjectedDestructuringPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/ReflectionTypesScalarDestructuringPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Policies/SimpleScalarConversionPolicy.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Rendering/Casing.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Rendering/MessageTemplateRenderer.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Rendering/Padding.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Settings/KeyValuePairs/CallableConfigurationMethodFinder.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Settings/KeyValuePairs/KeyValuePairSettings.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Settings/KeyValuePairs/SettingValueConversions.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Settings/KeyValuePairs/SurrogateConfigurationMethods.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |
| src/Serilog/Util/TimeProvider.cs | Not Attempted | - | 0 | 0% | 0 | 0 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|


