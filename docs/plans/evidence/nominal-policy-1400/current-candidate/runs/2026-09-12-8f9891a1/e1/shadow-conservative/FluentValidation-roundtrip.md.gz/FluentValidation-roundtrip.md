# FluentValidation — Round-Trip Verification Report

**Calor Version:** 0.21.0
**Date:** 2026-09-12
**Duration:** 63.4s
**Verdict:** PASS — 0 regressions
**Nullability acceptance:** Unadjudicated (not the legacy fidelity verdict)
**Evidence run:** `730d2659be2c4e9394263a7ed62a102c`; inventory complete: True
**Subject-test retry rule:** Fixed full-suite attempts per leg, declared before baseline; no early stop on green. Compare paired attempts and retain every test identity/outcome. Any failed, missing, skipped-extra or incomplete attempt blocks evidence acceptance, including legacy allowlisted flakes.
**Declared attempts per leg:** 2
- Program.Compile diagnostics expose Binder provenance only when BindingContext is present. Other producer passes are unavailable, not inferred from shared codes.
- Semantic resolution is unassessed; evaluated project context or absence of diagnostics does not prove every reference resolved or an accepted file is null-safe.
- GeneratedValidationReferencePool is the actual public reference pool, not a claim that every member was selected by the private lazy MetadataBinder. Project validation references are separately captured from evaluated compiler inputs.
- Calor0272/0273/0274 retain AnalysisOnly routing. Independent binding observations are shadow evidence, not a production nullability rejection or Stage A/B acceptance.
- Working-copy preparation omits .git, global.json, bin and obj. Compiler options are harness options (effects/contract enforcement off, generated validation deferred), not CLI defaults.

## Pipeline Summary

| Stage | Result |
|-------|--------|
| Baseline tests | 865 passed, 0 failed, 1 skipped |
| Files converted | 96/139 (69.1%) |
| Files reverted by recovery | 0 |
| Files with interop blocks | 15 |
| Build after replacement | Success |
| Round-trip tests | 865 passed, 0 failed, 1 skipped |
| Regressions | **0** |

## Fidelity (separated verdict dimensions)

### Conversion Coverage

| Metric | Value |
|--------|-------|
| Coverage (converted-and-kept / total) | **69.1%** (96/139) |
| Converted natively (zero losses) | 92 (66.2%) |
| Converted with losses | 4 |
| Reverted by recovery (coverage failures) | 0 |
| Failed conversion | 43 |
| Excluded by pattern (coverage failures in denominator) | 0 |
| Minimum total coverage | 50.0% |
| Minimum native coverage | 48.0% |
| Interop blocks (raw C# preserved) | 30 |
| Distinct semantic gaps | 1 |
| Loss ledger by kind | InteropPreserved: 30, PreprocessorStripped: 18 |

Gap features: `preprocessor-directive`

### Build Outcome

- Baseline succeeded: True
- Round-trip succeeded: True (exit 0)
- Files reverted to reach this outcome: 0
- Build errors: 0

### Test Outcome

- Baseline: 865/866 passed (1 TRX file(s))
- Round-trip: 865/866 passed (1 TRX file(s))
- Test inventory delta: 0
- Regressions: 0; new passes: 0; status: Pass

## File-by-File Results

| File | Status | Context mode | Contexts | Conv. Rate | Losses | Interop | Gaps | Errors |
|------|--------|--------------|----------|-----------|--------|---------|------|--------|
| src/FluentValidation/AbstractValidator.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'Validate' matches (OBJECT). Candidates: FluentVali... |
| src/FluentValidation/AssemblyInfo.FluentValidation.cs | Replaced | single-context-selected | 1 | 0% | 1 | 1 | - | - |
| src/FluentValidation/AssemblyScanner.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'AssemblyScanner..ctor' matches (OBJECT). Candidate... |
| src/FluentValidation/AsyncValidatorInvokedSynchronouslyException.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/DefaultValidatorExtensions_Validate.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | Compile Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | Lambda parameter '_' is already defined |
| src/FluentValidation/DefaultValidatorOptions.cs | Compile Error | single-context-selected | 1 | 100% | 3 | 3 | - | Lambda parameter '_' is already defined |
| src/FluentValidation/Enums.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/ICollectionRule.cs | Emit Error | single-context-selected | 1 | 100% | 0 | 0 | - | CS1003: Syntax error, ',' expected (line 15) |
| src/FluentValidation/InlineValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/AccessorCache.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 1 | 1 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/ChildRulesContainer.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | Emit Error | single-context-selected | 1 | 100% | 6 | 0 | preprocessor-directive | CS1525: Invalid expression term '}' (line 308) |
| src/FluentValidation/Internal/CompositeValidatorSelector.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 2 | 2 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/Extensions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Binding 'tmp' has no type annotation and no initializer. Add either ':type' (e.g... |
| src/FluentValidation/Internal/IncludeRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/IRuleComponent.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/MessageBuilderContext.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'Component' is already defined in 'FluentValidation.Internal.MessageBui... |
| src/FluentValidation/Internal/MessageFormatter.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Binding 'value' has no type annotation and no initializer. Add either ':type' (e... |
| src/FluentValidation/Internal/PropertyChain.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Internal/PropertyRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/RuleBase.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Binding 'index' has no type annotation and no initializer. Add either ':type' (e... |
| src/FluentValidation/Internal/RuleBuilder.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'Rule' is already defined in 'FluentValidation.Internal.RuleBuilder`2' |
| src/FluentValidation/Internal/RuleComponent.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/TrackingCollection.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Internal/ValidationStrategy.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/IValidationContext.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | Property 'Failures' is already defined in 'FluentValidation.ValidationContext`1' |
| src/FluentValidation/IValidationRule.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/IValidationRuleInternal.cs | Replaced | single-context-selected | 1 | 0% | 2 | 2 | - | - |
| src/FluentValidation/IValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/IValidatorDescriptor.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/IValidatorFactory.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/ILanguageManager.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/LanguageManager.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/ThaiLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Results/ValidationFailure.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Results/ValidationResult.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Syntax.cs | Emit Error | single-context-selected | 1 | 100% | 2 | 2 | - | CS1003: Syntax error, ',' expected (line 18) |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | '§YIELD' is illegal inside a property/indexer accessor. |
| src/FluentValidation/TestHelper/TestValidationResult.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/TestHelper/ValidationTestException.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | No overload of internal call 'GetModelLevelValidators' matches <T>(OBJECT). Cand... |
| src/FluentValidation/ValidationException.cs | Compile Error | single-context-selected | 1 | 100% | 4 | 0 | preprocessor-directive | No overload of internal call 'FluentValidation.ValidationException..ctor' matche... |
| src/FluentValidation/ValidatorDescriptor.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 4 | 4 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/ValidatorFactoryBase.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/ValidatorOptions.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Abs... |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/AsyncPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Validators/ComparableComparer.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Validators/EmailValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Validators/EmptyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/EnumValidator.cs | Compile Error | single-context-selected | 1 | 100% | 8 | 8 | - | No overload of internal call 'IsFlagsEnumDefined' matches (OBJECT, TProperty). C... |
| src/FluentValidation/Validators/EqualValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Equ... |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/GreaterThanValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/LengthValidator.cs | Emit Compilation Error | single-context-selected | 1 | 100% | 0 | 0 | - | /Users/juanrivera/.copilot/session-state/cea41f9d-a634-40dd-ad65-279680749d85/fi... |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/LessThanValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NoopPropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NotEmptyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NotEqualValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'ValueToCompare' is already defined in 'FluentValidation.Validators.Not... |
| src/FluentValidation/Validators/NotNullValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/NullValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | Compile Error | single-context-selected | 1 | 100% | 1 | 1 | - | Binding 'derivedValidatorFactory' has no type annotation and no initializer. Add... |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | Replaced | single-context-selected | 1 | 100% | 1 | 1 | - | - |
| src/FluentValidation/Validators/PredicateValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/PropertyValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |
| src/FluentValidation/Validators/RangeValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | Property 'From' is already defined in 'FluentValidation.Validators.RangeValidato... |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | Compile Error | single-context-selected | 1 | 100% | 0 | 0 | - | No overload of internal call 'CreateRegex' matches (OBJECT). Candidates: FluentV... |
| src/FluentValidation/Validators/StringEnumValidator.cs | Replaced | single-context-selected | 1 | 100% | 0 | 0 | - | - |

## Candidate diagnostics (retained before recovery)

Coordinates are one-based UTF-16 line/column; offsets are zero-based UTF-16. ConvertedCalor coordinates do not address the original C# despite a shared path. Analysis rows are independent observations, not production rejection or proof of resolution.

| File | Phase | Source | Code | Severity | Line:column | Binding disposition |
|---|---|---|---|---|---|---|
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AbstractValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 183: | - |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 38:12 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 154:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 168:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 267:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 276:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 38:12 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:80 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 63:80 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:17 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:46 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 97:29 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 97:45 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 100:24 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 100:51 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 102:23 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 116:33 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 119:56 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 119:77 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 122:27 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 122:43 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 128:24 | Uncataloged |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 128:108 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 129:19 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 131:19 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 131:43 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 154:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 168:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 182:46 | AnalysisOnly |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 267:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 276:9 | CompilationError |
| src/FluentValidation/AbstractValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 294:45 | AnalysisOnly |
| src/FluentValidation/AssemblyScanner.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 27:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 40:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 44:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 27:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 40:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 44:12 | CompilationError |
| src/FluentValidation/AssemblyScanner.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:41 | AnalysisOnly |
| src/FluentValidation/AssemblyScanner.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 53:19 | Uncataloged |
| src/FluentValidation/AsyncValidatorInvokedSynchronouslyException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/AsyncValidatorInvokedSynchronouslyException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/DefaultValidatorExtensions.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 367:21 | CompilationError |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 45:9 | Uncataloged |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:45 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 223:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 241:40 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 256:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 259:40 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 289:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 307:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 322:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 325:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 367:21 | CompilationError |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 490:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 505:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 508:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 509:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 525:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 540:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 543:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 544:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 560:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 576:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 579:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 580:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 596:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 611:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 614:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 615:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 631:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 646:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 649:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 650:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 666:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 682:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 685:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 686:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 702:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 717:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 720:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 721:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 737:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 740:39 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 741:15 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 757:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 865:31 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 873:31 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 886:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 887:48 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 888:12 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 911:31 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 915:29 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 916:82 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 916:120 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 917:28 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 920:28 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 921:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 923:33 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 924:26 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 924:40 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 925:21 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 932:47 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorExtensions.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 939:12 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 541: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 538: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 560: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 557: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 579: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 576: | - |
| src/FluentValidation/DefaultValidatorOptions.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 416:52 | CompilationError |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 62:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:86 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:92 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:102 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:96 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:102 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:112 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:22 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 133:69 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 134:55 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 149:69 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 150:55 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 191:41 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 191:46 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 205:41 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 205:46 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 245:84 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 246:65 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 261:84 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 262:65 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 303:48 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 303:53 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 303:60 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 317:48 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 317:53 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 317:60 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 328:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 338:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 355:72 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 355:78 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 355:88 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 355:139 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 365:37 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 368:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 376:29 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 379:31 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 381:42 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 387:92 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 390:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 397:97 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 400:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 407:97 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 410:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 416:17 | AnalysisOnly |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 416:52 | CompilationError |
| src/FluentValidation/DefaultValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 426:17 | AnalysisOnly |
| src/FluentValidation/ICollectionRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ICollectionRule.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 15:76 | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 74: | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 41:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 51:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 41:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 51:7 | CompilationError |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 110:32 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 119:32 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 124:24 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 125:44 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 126:67 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 128:44 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 128:66 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 128:91 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 129:30 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 130:31 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 131:31 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 132:30 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 133:23 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 135:24 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 135:51 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 136:67 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 138:44 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 138:57 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 138:82 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 139:30 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 140:31 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 141:31 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 142:30 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 143:23 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 145:48 | Uncataloged |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 157:77 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 171:32 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 172:42 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 173:32 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 174:31 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 175:39 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 181:32 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 85:14 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:14 | AnalysisOnly |
| src/FluentValidation/IValidationContext.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 74:14 | AnalysisOnly |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidationRule.cs | project-candidate-validation | MSBuildReportedLocation | CS1961 | Error | 27:12 | - |
| src/FluentValidation/IValidationRule.cs | project-candidate-validation | MSBuildReportedLocation | CS1961 | Error | 27:12 | - |
| src/FluentValidation/IValidationRuleInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 26: | - |
| src/FluentValidation/IValidationRuleInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 33: | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/IValidatorFactory.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/AccessorCache.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 38:41 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 38:23 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 38:41 | - |
| src/FluentValidation/Internal/AccessorCache.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 38:23 | - |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 27:36 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 29:22 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:31 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:38 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:47 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:92 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:61 | AnalysisOnly |
| src/FluentValidation/Internal/AccessorCache.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:53 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | emitted-syntax | EmittedCSharp | CS1525 | Error | 308:23 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | emitted-syntax | EmittedCSharp | CS1002 | Error | 308:23 | - |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 47:30 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:28 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:41 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:63 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:79 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 50:31 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:54 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:24 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:34 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:24 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:39 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:24 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 67:21 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 68:39 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 70:47 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 74:31 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 75:35 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:49 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 85:40 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 89:30 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 91:41 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 92:51 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 98:35 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 99:36 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 100:75 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 100:95 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 104:41 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 109:33 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 109:88 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 116:24 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 116:39 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 117:19 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 117:34 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 123:38 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 124:22 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 125:43 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 128:22 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 129:38 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 136:26 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 137:33 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 139:12 | AnalysisOnly |
| src/FluentValidation/Internal/CollectionPropertyRule.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 139:12 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 49: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 39: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 115: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 105: | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:35 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:38 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:41 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:44 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:53 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4032 | Error | 84:25 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 86:26 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 156:40 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:51 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4033 | Error | 178:29 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 179:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 179:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:35 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 18:38 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:41 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:44 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 84:53 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4032 | Error | 84:25 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 86:26 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 156:40 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 157:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 178:51 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS4033 | Error | 178:29 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS0748 | Error | 179:46 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 179:27 | - |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:41 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:46 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:48 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:53 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:64 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 152:60 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 156:44 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 158:14 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 174:60 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 178:51 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 178:58 | AnalysisOnly |
| src/FluentValidation/Internal/ConditionBuilder.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 180:14 | AnalysisOnly |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 16:67 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 16:67 | - |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 16:32 | AnalysisOnly |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 16:46 | AnalysisOnly |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 16:60 | AnalysisOnly |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 16:92 | AnalysisOnly |
| src/FluentValidation/Internal/DefaultValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 16:106 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 11:46 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 12:34 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 13:14 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 14:37 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:42 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:52 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:73 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:40 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:50 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:71 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:14 | AnalysisOnly |
| src/FluentValidation/Internal/Extensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:12 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 55:11 | - |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:16 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:41 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:56 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0250 | Error | 55:11 | CompilationError |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:16 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 60:9 | Uncataloged |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 61:12 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 64:34 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 65:26 | AnalysisOnly |
| src/FluentValidation/Internal/ExtensionsInternal.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 68:12 | AnalysisOnly |
| src/FluentValidation/Internal/IRuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 31: | - |
| src/FluentValidation/Internal/IRuleComponent.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IValidatorSelector.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IncludeRule.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/IncludeRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0508 | Error | 63:32 | - |
| src/FluentValidation/Internal/IncludeRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0508 | Error | 63:32 | - |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:75 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:64 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 56:11 | Uncataloged |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:46 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:14 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:14 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:14 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:14 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 31:14 | AnalysisOnly |
| src/FluentValidation/Internal/IncludeRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:14 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 38:5 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 39:34 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 173:58 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 38:5 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 39:34 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 173:58 | - |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:33 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:41 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 41:41 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:51 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 65:60 | AnalysisOnly |
| src/FluentValidation/Internal/MemberNameValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 74:12 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/MessageBuilderContext.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 54:12 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 34:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 34:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageBuilderContext.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:14 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/MessageFormatter.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 47:13 | CompilationError |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 23:9 | Uncataloged |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:31 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:19 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:76 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0250 | Error | 47:13 | CompilationError |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:16 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:30 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 49:49 | Uncataloged |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:76 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:38 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:53 | AnalysisOnly |
| src/FluentValidation/Internal/MessageFormatter.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:93 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 36:41 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:37 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:32 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:46 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:31 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:32 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 62:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 64:45 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 64:23 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 66:9 | Uncataloged |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 70:22 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 72:18 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 94:12 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:35 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:44 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:37 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyChain.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 15:14 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0738 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0738 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | project-candidate-validation | MSBuildReportedLocation | CS0535 | Error | 20:88 | - |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 40:30 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:28 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:41 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:63 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:78 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 43:30 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:34 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:39 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:34 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:21 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:27 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:71 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:91 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:38 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 63:41 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 66:22 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 67:38 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:50 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 76:37 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:29 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:79 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:28 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:70 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:85 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:44 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 86:29 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:24 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:39 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 90:19 | AnalysisOnly |
| src/FluentValidation/Internal/PropertyRule.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 90:34 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/RuleBase.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 191:11 | - |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 29:7 | CompilationError |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 77:7 | CompilationError |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 96:37 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 102:32 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:30 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 125:56 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 125:135 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 125:12 | CompilationError |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 125:12 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 129:12 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 135:41 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 138:41 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 148:41 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 151:41 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 158:35 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 165:40 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 175:23 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 180:23 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 187:57 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 189:74 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 190:94 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0250 | Error | 191:11 | CompilationError |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 203:51 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 204:49 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 205:17 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 205:88 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 206:17 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 206:39 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 206:108 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:17 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:51 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:78 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:147 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 208:24 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 208:54 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 209:19 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 210:24 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 210:65 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 90:34 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:28 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBase.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:33 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 19:7 | CompilationError |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 19:7 | CompilationError |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 31:34 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:34 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:76 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:78 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 89:58 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 91:28 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 91:42 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 91:56 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 93:28 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 93:51 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:23 | AnalysisOnly |
| src/FluentValidation/Internal/RuleBuilder.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:46 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 54:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 56:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 64:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 66:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 54:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 56:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0276 | Error | 64:36 | - |
| src/FluentValidation/Internal/RuleComponent.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 66:27 | - |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 67:35 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 75:40 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:35 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 87:40 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 96:30 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 97:36 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 99:32 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 101:12 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:71 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:79 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 105:26 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 106:32 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 114:31 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 120:38 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:29 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 24:34 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:42 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponent.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:37 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 31:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 41:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 31:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | project-candidate-validation | MSBuildReportedLocation | CS0273 | Error | 41:27 | - |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:23 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:57 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:23 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:74 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:14 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:14 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:14 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:42 | AnalysisOnly |
| src/FluentValidation/Internal/RuleComponentForNullableStruct.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:37 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 42:13 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 43:71 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 52:32 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 53:38 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 42:13 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1929 | Error | 43:71 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS0246 | Error | 52:32 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 53:38 | - |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:42 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:56 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:71 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:42 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:56 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:71 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 40:14 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:34 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:48 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:63 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:92 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 44:16 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:42 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:56 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:70 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:87 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 50:29 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 52:51 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 53:16 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:30 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:44 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:59 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 57:16 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:34 | AnalysisOnly |
| src/FluentValidation/Internal/RulesetValidatorSelector.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 60:18 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Internal/TrackingCollection.cs | project-candidate-validation | MSBuildReportedLocation | CS1551 | Error | 30:19 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | project-candidate-validation | MSBuildReportedLocation | CS1551 | Error | 30:19 | - |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 25:33 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 29:26 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:17 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:30 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:14 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 21:37 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:39 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 66:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 79:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:19 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:29 | AnalysisOnly |
| src/FluentValidation/Internal/TrackingCollection.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:19 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 47:52 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | project-candidate-validation | MSBuildReportedLocation | CS0225 | Error | 47:52 | - |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:36 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 29:36 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:27 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:27 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:37 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 55:36 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 65:33 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 77:42 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 78:44 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 78:64 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 78:91 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:42 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:38 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:36 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 86:45 | AnalysisOnly |
| src/FluentValidation/Internal/ValidationStrategy.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 94:54 | AnalysisOnly |
| src/FluentValidation/Resources/ILanguageManager.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 102:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 108:31 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 112:35 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 115:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 102:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 108:31 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 112:35 | - |
| src/FluentValidation/Resources/LanguageManager.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 115:27 | - |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 24:48 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 25:47 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 26:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 27:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 28:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 29:46 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 30:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 31:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 32:42 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 33:50 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 34:51 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 35:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 36:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 38:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 39:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 40:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 41:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 42:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 43:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 44:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 45:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 46:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 47:42 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 48:42 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 49:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 50:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 51:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 52:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 53:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 54:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 55:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 56:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 57:48 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 58:49 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 59:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 60:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 61:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 62:49 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 63:41 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 64:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 65:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 66:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 67:42 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 68:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 69:48 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 70:45 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 71:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 72:37 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 73:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 74:42 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 75:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 76:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 77:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 78:46 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 79:40 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 80:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 81:38 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 82:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:18 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 83:18 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 23:9 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 98:24 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 98:24 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 100:51 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 101:43 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 102:60 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:39 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:49 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:71 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 106:36 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 107:44 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 108:62 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 110:36 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 110:46 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 110:59 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 111:31 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 111:61 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 111:81 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 113:62 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 116:58 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 117:12 | AnalysisOnly |
| src/FluentValidation/Resources/LanguageManager.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 127:9 | Uncataloged |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/AlbanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ArabicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/AzerbaijaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BengaliLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BosnianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/BulgarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CatalanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseSimplifiedLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ChineseTraditionalLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CroatianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/CzechLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/DutchLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 39:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EnglishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 10:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/EstonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FinnishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/FrenchLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GeorgianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GermanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/GreekLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HebrewLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HindiLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/HungarianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IcelandicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/IndonesianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ItalianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/JapaneseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KazakhLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KhmerLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/KoreanLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/LatvianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/MacedonianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianBokmalLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/NorwegianNynorskLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PersianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PolishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseBrazilLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/PortugueseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RomanshLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/RussianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SerbianLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovakLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SlovenianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SpanishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/SwedishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TajikLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TamilLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TeluguLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ThaiLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 36:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ThaiLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 36:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/ThaiLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 7:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/TurkishLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UkrainianLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekCyrillicLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/UzbekLatinLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/VietnameseLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:18 | AnalysisOnly |
| src/FluentValidation/Resources/Languages/WelshLanguage.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 8:9 | AnalysisOnly |
| src/FluentValidation/Results/ValidationFailure.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 29:14 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 81:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 82:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 81:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 82:35 | - |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 69:25 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 69:12 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 74:60 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:48 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:56 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 84:56 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 88:61 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:72 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 34:72 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 39:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 48:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:78 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:82 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:101 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 14:18 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:32 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:74 | AnalysisOnly |
| src/FluentValidation/Results/ValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:74 | AnalysisOnly |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 121: | - |
| src/FluentValidation/Syntax.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 125: | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 18:83 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 31:83 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 36:93 | - |
| src/FluentValidation/Syntax.cs | emitted-syntax | EmittedCSharp | CS1003 | Error | 41:87 | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ITestValidationContinuation.cs | Program.Compile | ConvertedCalor | Calor0209 | Error | 35:17 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:23 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 80:28 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 51:23 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 80:28 | - |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 21:30 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 26:30 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 31:45 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:48 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:56 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:120 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:163 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:205 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:263 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:31 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 68:31 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 72:68 | Uncataloged |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:125 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:168 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:210 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:268 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 83:27 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 86:39 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 97:31 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 15:14 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:17 | AnalysisOnly |
| src/FluentValidation/TestHelper/TestValidationResult.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:34 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidationTestException.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 48: | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 25:89 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 142:27 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 158:27 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:59 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 25:89 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 25:160 | Uncataloged |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 28:32 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:65 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 31:32 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:52 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 33:27 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 35:69 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 37:51 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:142 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 37:96 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:162 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 41:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 42:42 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:46 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:77 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:73 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 55:42 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:65 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:68 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:81 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 58:31 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 75:48 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 79:71 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 103:45 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 103:63 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 104:37 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:108 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:139 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 105:200 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 115:31 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 120:37 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 121:98 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 125:39 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 126:39 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 126:81 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 127:88 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 137:56 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 142:27 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 142:27 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 152:56 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 158:27 | CompilationError |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0272 | Error | 158:27 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 163:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 171:93 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 171:154 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 175:162 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 179:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 183:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 187:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 191:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 195:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 199:64 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 204:32 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:26 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 207:46 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 208:67 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 209:36 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 210:38 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 212:23 | AnalysisOnly |
| src/FluentValidation/TestHelper/ValidatorTestExtensions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 223:31 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 17:9 | CompilationError |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:6 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:29 | AnalysisOnly |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 17:9 | CompilationError |
| src/FluentValidation/ValidationException.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 30:38 | Uncataloged |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 34:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | project-candidate-validation | MSBuildReportedLocation | CS8917 | Error | 35:23 | - |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:82 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:61 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 27:12 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 31:19 | Uncataloged |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 34:36 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 35:37 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 35:60 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 36:15 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 46:15 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:31 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:24 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 54:12 | AnalysisOnly |
| src/FluentValidation/ValidatorDescriptor.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 63:15 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 66:35 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 68:25 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 69:16 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 70:12 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:12 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 73:12 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 76:12 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 76:12 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 47:51 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 53:50 | AnalysisOnly |
| src/FluentValidation/ValidatorOptions.cs | shadow-bind | ConvertedCalor | Calor0202 | Error | 61:48 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 26:7 | CompilationError |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 26:7 | CompilationError |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:38 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:37 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 49:97 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:82 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 51:106 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 57:44 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:55 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:36 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 61:56 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 62:50 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 63:43 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:41 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:71 | AnalysisOnly |
| src/FluentValidation/Validators/AbstractComparisonValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 28:78 | AnalysisOnly |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:30 | AnalysisOnly |
| src/FluentValidation/Validators/AsyncPredicateValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 26:12 | AnalysisOnly |
| src/FluentValidation/Validators/AsyncPropertyValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 27:12 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 44:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 59:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 44:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | project-candidate-validation | MSBuildReportedLocation | CS0029 | Error | 59:31 | - |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:30 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:34 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 45:76 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:30 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 55:34 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:76 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 67:48 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:23 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 74:44 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 79:111 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 83:31 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 87:11 | Uncataloged |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 91:30 | AnalysisOnly |
| src/FluentValidation/Validators/ChildValidatorAdaptor.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 92:40 | AnalysisOnly |
| src/FluentValidation/Validators/CreditCardValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 25:32 | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 25:32 | - |
| src/FluentValidation/Validators/CreditCardValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 17:12 | AnalysisOnly |
| src/FluentValidation/Validators/CreditCardValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:30 | AnalysisOnly |
| src/FluentValidation/Validators/EmailValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 47:5 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 48:34 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | SYSLIB1043 | Error | 47:5 | - |
| src/FluentValidation/Validators/EmailValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0759 | Error | 48:34 | - |
| src/FluentValidation/Validators/EmailValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:30 | AnalysisOnly |
| src/FluentValidation/Validators/EmailValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 41:12 | AnalysisOnly |
| src/FluentValidation/Validators/EmailValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:30 | AnalysisOnly |
| src/FluentValidation/Validators/EmailValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 59:12 | AnalysisOnly |
| src/FluentValidation/Validators/EmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 15:30 | AnalysisOnly |
| src/FluentValidation/Validators/EmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 19:55 | AnalysisOnly |
| src/FluentValidation/Validators/EmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 23:71 | AnalysisOnly |
| src/FluentValidation/Validators/EmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 26:12 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EnumValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 31:14 | CompilationError |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 24:30 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 27:23 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 29:42 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:50 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 31:14 | CompilationError |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:22 | AnalysisOnly |
| src/FluentValidation/Validators/EnumValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 123:12 | AnalysisOnly |
| src/FluentValidation/Validators/EqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/EqualValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 25:7 | CompilationError |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 25:7 | CompilationError |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 55:30 | AnalysisOnly |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 56:24 | AnalysisOnly |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:34 | AnalysisOnly |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 65:12 | AnalysisOnly |
| src/FluentValidation/Validators/EqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:14 | AnalysisOnly |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 25:44 | AnalysisOnly |
| src/FluentValidation/Validators/ExclusiveBetweenValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 25:84 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:39 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 45:12 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:14 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:39 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 42:12 | AnalysisOnly |
| src/FluentValidation/Validators/GreaterThanValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 15:14 | AnalysisOnly |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/IPropertyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 24:43 | AnalysisOnly |
| src/FluentValidation/Validators/InclusiveBetweenValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 24:82 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 218:65 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 218:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 189:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 189:69 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 218:65 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 218:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS0103 | Error | 189:60 | - |
| src/FluentValidation/Validators/LengthValidator.cs | project-candidate-validation | MSBuildReportedLocation | CS1503 | Error | 189:69 | - |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:30 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 42:36 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 42:54 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 43:35 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:35 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 54:12 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 78:12 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 102:12 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 97:14 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 126:12 | AnalysisOnly |
| src/FluentValidation/Validators/LengthValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 122:14 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:39 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 45:12 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanOrEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:14 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 37:39 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 42:12 | AnalysisOnly |
| src/FluentValidation/Validators/LessThanValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 15:14 | AnalysisOnly |
| src/FluentValidation/Validators/NotEmptyValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/NotEmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 18:30 | AnalysisOnly |
| src/FluentValidation/Validators/NotEmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:55 | AnalysisOnly |
| src/FluentValidation/Validators/NotEmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:83 | AnalysisOnly |
| src/FluentValidation/Validators/NotEmptyValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 30:12 | AnalysisOnly |
| src/FluentValidation/Validators/NotEqualValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 23:7 | CompilationError |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 54:30 | AnalysisOnly |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 55:24 | AnalysisOnly |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 59:34 | AnalysisOnly |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 64:12 | AnalysisOnly |
| src/FluentValidation/Validators/NotEqualValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 20:14 | AnalysisOnly |
| src/FluentValidation/Validators/NotNullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/NotNullValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 14:22 | AnalysisOnly |
| src/FluentValidation/Validators/NotNullValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 17:12 | AnalysisOnly |
| src/FluentValidation/Validators/NullValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/NullValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 14:22 | AnalysisOnly |
| src/FluentValidation/Validators/NullValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 17:12 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | 111: | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | Program.Compile | ConvertedCalor | Calor0250 | Error | 74:11 | - |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 27:41 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 29:9 | Uncataloged |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 38:41 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 40:99 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 50:41 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 52:103 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 60:37 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 62:34 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0931 | Info | 66:50 | Uncataloged |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 71:30 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 72:14 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 73:88 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0250 | Error | 74:11 | CompilationError |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 76:12 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:132 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:165 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 80:174 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 81:48 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 82:12 | AnalysisOnly |
| src/FluentValidation/Validators/PolymorphicValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:42 | AnalysisOnly |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Info | 95: | - |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:27 | AnalysisOnly |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 30:48 | AnalysisOnly |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 31:54 | AnalysisOnly |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:57 | AnalysisOnly |
| src/FluentValidation/Validators/PrecisionScaleValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 41:12 | AnalysisOnly |
| src/FluentValidation/Validators/PredicateValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/PredicateValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 22:48 | AnalysisOnly |
| src/FluentValidation/Validators/PredicateValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 28:12 | AnalysisOnly |
| src/FluentValidation/Validators/PropertyValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 23:12 | AnalysisOnly |
| src/FluentValidation/Validators/RangeValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 15:7 | CompilationError |
| src/FluentValidation/Validators/RangeValidator.cs | Program.Compile | ConvertedCalor | Calor0201 | Error | 18:7 | CompilationError |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 15:7 | CompilationError |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0201 | Error | 18:7 | CompilationError |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 33:30 | AnalysisOnly |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:42 | AnalysisOnly |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 46:12 | AnalysisOnly |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 53:74 | AnalysisOnly |
| src/FluentValidation/Validators/RangeValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 58:74 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | CSharpToCalorConverter.Convert | OriginalCSharp | (not supplied) | Warning | : | - |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | Program.Compile | ConvertedCalor | Calor0208 | Error | 35:45 | CompilationError |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 44:30 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 46:34 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 47:44 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0270 | Info | 47:56 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 62:12 | AnalysisOnly |
| src/FluentValidation/Validators/RegularExpressionValidator.cs | shadow-bind | ConvertedCalor | Calor0208 | Error | 35:45 | CompilationError |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 24:30 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:42 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 26:67 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 32:23 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 1:1 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0273 | Error | 37:12 | AnalysisOnly |
| src/FluentValidation/Validators/StringEnumValidator.cs | shadow-bind | ConvertedCalor | Calor0200 | Error | 17:33 | AnalysisOnly |

## Regression Analysis

No regressions detected. All previously-passing tests continue to pass.

