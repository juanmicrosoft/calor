# Calor Conversion Scorecard

**Commit:** `48cae9117`
**Date:** 2026-10-20 13:00:47 UTC

## Summary

| Metric | Count | Rate |
|--------|-------|------|
| Fully converted | 95/100 | 95% |
| Partially converted | 5/100 | 5% |
| Blocked | 0/100 | 0% |
| Crashed | 0/100 | 0% |
| **Round-trip verified** | **98/100** | **98%** |

## By Level

| Level | Passing | Total | Rate |
|-------|---------|-------|------|
| Level 1 | 20 | 20 | 100% |
| Level 2 | 20 | 20 | 100% |
| Level 3 | 20 | 20 | 100% |
| Level 4 | 19 | 20 | 95% |
| Level 5 | 19 | 20 | 95% |

## By C# Feature (lowest conversion rates)

| Feature | Passing | Total | Rate |
|---------|---------|-------|------|
| record | 0 | 2 | 0% |
| unary_minus | 0 | 1 | 0% |
| unary_plus | 0 | 1 | 0% |
| positional_record | 0 | 1 | 0% |
| generic_method | 0 | 1 | 0% |
| type_constraint | 0 | 1 | 0% |
| with_expression | 0 | 1 | 0% |
| computed_property | 0 | 1 | 0% |
| indexer | 1 | 2 | 50% |
| binary_expression | 6 | 6 | 100% |
| for_loop | 6 | 6 | 100% |
| linq | 5 | 5 | 100% |
| parameters | 4 | 4 | 100% |
| static_class | 3 | 3 | 100% |
| recursion | 3 | 3 | 100% |
| namespace | 2 | 2 | 100% |
| console_write | 2 | 2 | 100% |
| int_literal | 2 | 2 | 100% |
| multiple_methods | 2 | 2 | 100% |
| modulo | 2 | 2 | 100% |

## Failed Snippets

| ID | File | Status | Top Issue |
|----|------|--------|-----------|
| 078 | Level4_Methods/078_IndexerProperty.cs | PartiallyConverted | Warning [nullable-oblivious-nested-shape] (line 5, col 17): Nested oblivious ... |
| 086 | Level5_Advanced/086_GenericMethod.cs | PartiallyConverted | Warning [ref-parameter] (line 10): Unsupported feature [ref-parameter] escala... |
