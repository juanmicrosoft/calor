| Published file | A SHA-256 | B SHA-256 | Same |
|---|---|---|---|
| `Calor.Sdk.0.25.0.nupkg` | `88b93090f6e94fec634da29c69ecc865962b799aaefda162c7b215036b8f3460` | `88b93090f6e94fec634da29c69ecc865962b799aaefda162c7b215036b8f3460` | yes |
| `calor.0.25.0.nupkg` | `a9669d7daf36c3a4c27ed045e28b63f7a9e0a25602638b0ae6d8f1ebf5cacf1e` | `a9669d7daf36c3a4c27ed045e28b63f7a9e0a25602638b0ae6d8f1ebf5cacf1e` | yes |
| `calor-nuget-48cae911700ceb0dfc358e00933650445d81604f.provenance.json` | `693d4c3531fe652986dddb97db37afb43a22733442672dda41aac3144e9750c8` | `693d4c3531fe652986dddb97db37afb43a22733442672dda41aac3144e9750c8` | yes |
| `calor-nuget-48cae911700ceb0dfc358e00933650445d81604f.sbom.spdx.json` | `ac50e35276ac69954bd606208e723b653e1fd75fd13b63a4a5170b108450493b` | `ac50e35276ac69954bd606208e723b653e1fd75fd13b63a4a5170b108450493b` | yes |

Package entries compared (content hash and zip timestamp): 97.
Differences: 0.

Toolchains:
- A: {"dotnet": "10.0.401", "dotnetSdkBuild": "sha256:a5b223b4a6d67e85e803b56f2fc5fb52b042f2c27a73e872c3c899dd21bd8465", "node": "v22.23.3", "npm": "10.9.9", "os": "Linux x86_64"}
- B: {"dotnet": "10.0.401", "dotnetSdkBuild": "sha256:a5b223b4a6d67e85e803b56f2fc5fb52b042f2c27a73e872c3c899dd21bd8465", "node": "v22.23.3", "npm": "10.9.9", "os": "Linux x86_64"}
